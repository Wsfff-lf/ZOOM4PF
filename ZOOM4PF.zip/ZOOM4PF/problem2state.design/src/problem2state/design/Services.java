package problem2state.design;
//import problemframework.State;

//import org.eclipse.emf.ecore.EObject;
//import org.eclipse.uml2.uml.*;
//import org.eclipse.uml2.uml.NamedElement;
//
//import problemframework.*;
//import problemframework.Region;
//import problemframework.Transition;
//import problemframework.Vertex;
///**
// * The services class used by VSM.
// */
	public class Services {
//    
//    /**
//    * See http://help.eclipse.org/neon/index.jsp?topic=%2Forg.eclipse.sirius.doc%2Fdoc%2Findex.html&cp=24 for documentation on how to write service methods.
//    */
//	public void createTransition(NamedElement  self, EObject source_p, EObject target_p){
//		EObject source = source_p;
//		EObject target = target_p;
//		if (source instanceof Region){
//			source = source.getOwner();
//		}
//		if (target instanceof Region){
//			target = target.getOwner();
//		}
//		if (source instanceof Vertex
//				&& target instanceof Vertex
//				&& source.eContainer() == target.eContainer()) {
//			createTransition((Region)source.eContainer(), (Vertex)source, (Vertex)target);
//		}
//
//	}
//
//	private void createTransition(Region region, Vertex source, Vertex target) {
//		final Transition transition = ProblemframeworkFactory.eINSTANCE.createTransition();
//		transition.setSource(source);
//		transition.setTarget(target);
//		region.getTransitions().add(transition);
//	}
//	public boolean hasDo(State state) {
//		return state.getDoActivity()!=null;
//	}
//	public boolean hasEntry(State state) {
//		return state.getEntry()!=null;
//	}
//	public boolean hasExit(State state) {
//		return state.getExit() != null;
//	}
//	
//	
//	public boolean hasNoDo(State state) {
//		return !hasDo(state);
//	}
//	public boolean hasNoEntry(State state) {
//		return !hasEntry(state);
//	}
//	public boolean hasNoExit(State state) {
//		return !hasExit(state);
//	}
}
