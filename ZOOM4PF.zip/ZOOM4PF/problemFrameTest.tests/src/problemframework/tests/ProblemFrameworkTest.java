/**
 */
package problemframework.tests;

import junit.textui.TestRunner;

import problemframework.ProblemFramework;
import problemframework.ProblemframeworkFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Problem Framework</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class ProblemFrameworkTest extends SubPFTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ProblemFrameworkTest.class);
	}

	/**
	 * Constructs a new Problem Framework test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProblemFrameworkTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Problem Framework test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected ProblemFramework getFixture() {
		return (ProblemFramework)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ProblemframeworkFactory.eINSTANCE.createProblemFramework());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //ProblemFrameworkTest
