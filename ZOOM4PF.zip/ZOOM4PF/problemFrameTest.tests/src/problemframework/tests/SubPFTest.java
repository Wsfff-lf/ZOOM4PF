/**
 */
package problemframework.tests;

import junit.framework.TestCase;

import problemframework.SubPF;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Sub PF</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class SubPFTest extends TestCase {

	/**
	 * The fixture for this Sub PF test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SubPF fixture = null;

	/**
	 * Constructs a new Sub PF test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SubPFTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Sub PF test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(SubPF fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Sub PF test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SubPF getFixture() {
		return fixture;
	}

} //SubPFTest
