/**
 */
package problemframework.tests;

import junit.framework.Test;
import junit.framework.TestSuite;

import junit.textui.TestRunner;

import stateMachine.tests.StateMachineTests;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>Problemframework</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class ProblemframeworkAllTests extends TestSuite {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test suite() {
		TestSuite suite = new ProblemframeworkAllTests("Problemframework Tests");
		suite.addTest(StateMachineTests.suite());
		return suite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProblemframeworkAllTests(String name) {
		super(name);
	}

} //ProblemframeworkAllTests
