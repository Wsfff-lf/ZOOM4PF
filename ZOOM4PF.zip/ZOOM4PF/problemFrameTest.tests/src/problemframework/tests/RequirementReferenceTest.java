/**
 */
package problemframework.tests;

import junit.textui.TestRunner;

import problemframework.ProblemframeworkFactory;
import problemframework.RequirementReference;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Requirement Reference</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class RequirementReferenceTest extends ReferenceTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(RequirementReferenceTest.class);
	}

	/**
	 * Constructs a new Requirement Reference test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RequirementReferenceTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Requirement Reference test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected RequirementReference getFixture() {
		return (RequirementReference)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ProblemframeworkFactory.eINSTANCE.createRequirementReference());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //RequirementReferenceTest
