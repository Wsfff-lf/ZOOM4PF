/**
 */
package problemframework.tests;

import junit.textui.TestRunner;

import problemframework.ProblemframeworkFactory;
import problemframework.RequirementConstraint;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Requirement Constraint</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class RequirementConstraintTest extends ReferenceTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(RequirementConstraintTest.class);
	}

	/**
	 * Constructs a new Requirement Constraint test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RequirementConstraintTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Requirement Constraint test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected RequirementConstraint getFixture() {
		return (RequirementConstraint)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ProblemframeworkFactory.eINSTANCE.createRequirementConstraint());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //RequirementConstraintTest
