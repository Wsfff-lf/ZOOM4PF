/**
 */
package stateMachine.tests;

import junit.textui.TestRunner;

import stateMachine.ConnectionPointReference;
import stateMachine.StateMachineFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Connection Point Reference</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class ConnectionPointReferenceTest extends VertexTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ConnectionPointReferenceTest.class);
	}

	/**
	 * Constructs a new Connection Point Reference test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConnectionPointReferenceTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Connection Point Reference test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected ConnectionPointReference getFixture() {
		return (ConnectionPointReference)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(StateMachineFactory.eINSTANCE.createConnectionPointReference());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //ConnectionPointReferenceTest
