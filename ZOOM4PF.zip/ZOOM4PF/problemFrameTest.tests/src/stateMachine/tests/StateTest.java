/**
 */
package stateMachine.tests;

import junit.textui.TestRunner;

import stateMachine.State;
import stateMachine.StateMachineFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are tested:
 * <ul>
 *   <li>{@link stateMachine.State#isIsComposite() <em>Is Composite</em>}</li>
 *   <li>{@link stateMachine.State#isIsOrthogonal() <em>Is Orthogonal</em>}</li>
 *   <li>{@link stateMachine.State#isIsSimple() <em>Is Simple</em>}</li>
 *   <li>{@link stateMachine.State#isIsSubmachineState() <em>Is Submachine State</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class StateTest extends VertexTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(StateTest.class);
	}

	/**
	 * Constructs a new State test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StateTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this State test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected State getFixture() {
		return (State)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(StateMachineFactory.eINSTANCE.createState());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link stateMachine.State#isIsComposite() <em>Is Composite</em>}' feature getter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see stateMachine.State#isIsComposite()
	 * @generated
	 */
	public void testIsIsComposite() {
		// TODO: implement this feature getter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link stateMachine.State#setIsComposite(boolean) <em>Is Composite</em>}' feature setter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see stateMachine.State#setIsComposite(boolean)
	 * @generated
	 */
	public void testSetIsComposite() {
		// TODO: implement this feature setter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link stateMachine.State#isIsOrthogonal() <em>Is Orthogonal</em>}' feature getter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see stateMachine.State#isIsOrthogonal()
	 * @generated
	 */
	public void testIsIsOrthogonal() {
		// TODO: implement this feature getter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link stateMachine.State#setIsOrthogonal(boolean) <em>Is Orthogonal</em>}' feature setter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see stateMachine.State#setIsOrthogonal(boolean)
	 * @generated
	 */
	public void testSetIsOrthogonal() {
		// TODO: implement this feature setter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link stateMachine.State#isIsSimple() <em>Is Simple</em>}' feature getter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see stateMachine.State#isIsSimple()
	 * @generated
	 */
	public void testIsIsSimple() {
		// TODO: implement this feature getter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link stateMachine.State#setIsSimple(boolean) <em>Is Simple</em>}' feature setter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see stateMachine.State#setIsSimple(boolean)
	 * @generated
	 */
	public void testSetIsSimple() {
		// TODO: implement this feature setter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link stateMachine.State#isIsSubmachineState() <em>Is Submachine State</em>}' feature getter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see stateMachine.State#isIsSubmachineState()
	 * @generated
	 */
	public void testIsIsSubmachineState() {
		// TODO: implement this feature getter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link stateMachine.State#setIsSubmachineState(boolean) <em>Is Submachine State</em>}' feature setter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see stateMachine.State#setIsSubmachineState(boolean)
	 * @generated
	 */
	public void testSetIsSubmachineState() {
		// TODO: implement this feature setter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //StateTest
