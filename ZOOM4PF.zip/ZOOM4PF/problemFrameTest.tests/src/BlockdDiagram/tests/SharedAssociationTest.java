/**
 */
package BlockdDiagram.tests;

import BlockdDiagram.BlockdDiagramFactory;
import BlockdDiagram.SharedAssociation;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Shared Association</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class SharedAssociationTest extends TestCase {

	/**
	 * The fixture for this Shared Association test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SharedAssociation fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(SharedAssociationTest.class);
	}

	/**
	 * Constructs a new Shared Association test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SharedAssociationTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Shared Association test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(SharedAssociation fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Shared Association test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SharedAssociation getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(BlockdDiagramFactory.eINSTANCE.createSharedAssociation());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //SharedAssociationTest
