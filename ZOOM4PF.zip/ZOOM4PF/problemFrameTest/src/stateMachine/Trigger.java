/**
 */
package stateMachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Trigger</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see stateMachine.StateMachinePackage#getTrigger()
 * @model
 * @generated
 */
public interface Trigger extends EObject {
} // Trigger
