/**
 */
package stateMachine;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State Machine</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link stateMachine.StateMachine#getSubstatemachine <em>Substatemachine</em>}</li>
 *   <li>{@link stateMachine.StateMachine#getSubmachineState <em>Submachine State</em>}</li>
 *   <li>{@link stateMachine.StateMachine#getConnectionPoint <em>Connection Point</em>}</li>
 *   <li>{@link stateMachine.StateMachine#getRegion <em>Region</em>}</li>
 * </ul>
 *
 * @see stateMachine.StateMachinePackage#getStateMachine()
 * @model
 * @generated
 */
public interface StateMachine extends Behavior {
	/**
	 * Returns the value of the '<em><b>Substatemachine</b></em>' containment reference list.
	 * The list contents are of type {@link stateMachine.StateMachine}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Substatemachine</em>' containment reference list.
	 * @see stateMachine.StateMachinePackage#getStateMachine_Substatemachine()
	 * @model containment="true"
	 * @generated
	 */
	EList<StateMachine> getSubstatemachine();

	/**
	 * Returns the value of the '<em><b>Submachine State</b></em>' reference list.
	 * The list contents are of type {@link stateMachine.State}.
	 * It is bidirectional and its opposite is '{@link stateMachine.State#getSubmachine <em>Submachine</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Submachine State</em>' reference list.
	 * @see stateMachine.StateMachinePackage#getStateMachine_SubmachineState()
	 * @see stateMachine.State#getSubmachine
	 * @model opposite="submachine"
	 * @generated
	 */
	EList<State> getSubmachineState();

	/**
	 * Returns the value of the '<em><b>Connection Point</b></em>' containment reference list.
	 * The list contents are of type {@link stateMachine.Pseudostate}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connection Point</em>' containment reference list.
	 * @see stateMachine.StateMachinePackage#getStateMachine_ConnectionPoint()
	 * @model containment="true"
	 * @generated
	 */
	EList<Pseudostate> getConnectionPoint();

	/**
	 * Returns the value of the '<em><b>Region</b></em>' containment reference list.
	 * The list contents are of type {@link stateMachine.Region}.
	 * It is bidirectional and its opposite is '{@link stateMachine.Region#getStatemachine <em>Statemachine</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Region</em>' containment reference list.
	 * @see stateMachine.StateMachinePackage#getStateMachine_Region()
	 * @see stateMachine.Region#getStatemachine
	 * @model opposite="statemachine" containment="true" required="true"
	 * @generated
	 */
	EList<Region> getRegion();

} // StateMachine
