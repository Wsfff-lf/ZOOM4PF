/**
 */
package BlockdDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Generalization</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link BlockdDiagram.Generalization#getSource <em>Source</em>}</li>
 *   <li>{@link BlockdDiagram.Generalization#getTarget <em>Target</em>}</li>
 *   <li>{@link BlockdDiagram.Generalization#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see BlockdDiagram.BlockdDiagramPackage#getGeneralization()
 * @model
 * @generated
 */
public interface Generalization extends EObject {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Block)
	 * @see BlockdDiagram.BlockdDiagramPackage#getGeneralization_Source()
	 * @model
	 * @generated
	 */
	Block getSource();

	/**
	 * Sets the value of the '{@link BlockdDiagram.Generalization#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Block value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(Block)
	 * @see BlockdDiagram.BlockdDiagramPackage#getGeneralization_Target()
	 * @model
	 * @generated
	 */
	Block getTarget();

	/**
	 * Sets the value of the '{@link BlockdDiagram.Generalization#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(Block value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see BlockdDiagram.BlockdDiagramPackage#getGeneralization_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link BlockdDiagram.Generalization#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // Generalization
