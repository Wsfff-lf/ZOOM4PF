/**
 */
package BlockdDiagram;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Block</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link BlockdDiagram.Block#getOperations <em>Operations</em>}</li>
 *   <li>{@link BlockdDiagram.Block#getPropertys <em>Propertys</em>}</li>
 *   <li>{@link BlockdDiagram.Block#getName <em>Name</em>}</li>
 *   <li>{@link BlockdDiagram.Block#getPart <em>Part</em>}</li>
 *   <li>{@link BlockdDiagram.Block#getItemflow <em>Itemflow</em>}</li>
 *   <li>{@link BlockdDiagram.Block#getPort <em>Port</em>}</li>
 *   <li>{@link BlockdDiagram.Block#getConnect <em>Connect</em>}</li>
 * </ul>
 *
 * @see BlockdDiagram.BlockdDiagramPackage#getBlock()
 * @model
 * @generated
 */
public interface Block extends EObject {
	/**
	 * Returns the value of the '<em><b>Operations</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.Operations}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operations</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getBlock_Operations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Operations> getOperations();

	/**
	 * Returns the value of the '<em><b>Propertys</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.Propertys}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Propertys</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getBlock_Propertys()
	 * @model containment="true"
	 * @generated
	 */
	EList<Propertys> getPropertys();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see BlockdDiagram.BlockdDiagramPackage#getBlock_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link BlockdDiagram.Block#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Part</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.Part}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Part</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getBlock_Part()
	 * @model containment="true"
	 * @generated
	 */
	EList<Part> getPart();

	/**
	 * Returns the value of the '<em><b>Itemflow</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.ItemFlow}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Itemflow</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getBlock_Itemflow()
	 * @model containment="true"
	 * @generated
	 */
	EList<ItemFlow> getItemflow();

	/**
	 * Returns the value of the '<em><b>Port</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.Port}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getBlock_Port()
	 * @model containment="true"
	 * @generated
	 */
	EList<Port> getPort();

	/**
	 * Returns the value of the '<em><b>Connect</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.Connect}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connect</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getBlock_Connect()
	 * @model containment="true"
	 * @generated
	 */
	EList<Connect> getConnect();

} // Block
