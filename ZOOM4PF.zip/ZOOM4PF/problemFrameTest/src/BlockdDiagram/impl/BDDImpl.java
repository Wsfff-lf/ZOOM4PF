/**
 */
package BlockdDiagram.impl;

import BlockdDiagram.BDD;
import BlockdDiagram.Block;
import BlockdDiagram.BlockdDiagramPackage;
import BlockdDiagram.Dependency;
import BlockdDiagram.Generalization;
import BlockdDiagram.PartAssociation;
import BlockdDiagram.SharedAssociation;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>BDD</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link BlockdDiagram.impl.BDDImpl#getBlock <em>Block</em>}</li>
 *   <li>{@link BlockdDiagram.impl.BDDImpl#getShared <em>Shared</em>}</li>
 *   <li>{@link BlockdDiagram.impl.BDDImpl#getGeneral <em>General</em>}</li>
 *   <li>{@link BlockdDiagram.impl.BDDImpl#getDependency <em>Dependency</em>}</li>
 *   <li>{@link BlockdDiagram.impl.BDDImpl#getPartass <em>Partass</em>}</li>
 *   <li>{@link BlockdDiagram.impl.BDDImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BDDImpl extends MinimalEObjectImpl.Container implements BDD {
	/**
	 * The cached value of the '{@link #getBlock() <em>Block</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBlock()
	 * @generated
	 * @ordered
	 */
	protected EList<Block> block;

	/**
	 * The cached value of the '{@link #getShared() <em>Shared</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShared()
	 * @generated
	 * @ordered
	 */
	protected EList<SharedAssociation> shared;

	/**
	 * The cached value of the '{@link #getGeneral() <em>General</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGeneral()
	 * @generated
	 * @ordered
	 */
	protected EList<Generalization> general;

	/**
	 * The cached value of the '{@link #getDependency() <em>Dependency</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDependency()
	 * @generated
	 * @ordered
	 */
	protected EList<Dependency> dependency;

	/**
	 * The cached value of the '{@link #getPartass() <em>Partass</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPartass()
	 * @generated
	 * @ordered
	 */
	protected EList<PartAssociation> partass;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BDDImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BlockdDiagramPackage.Literals.BDD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Block> getBlock() {
		if (block == null) {
			block = new EObjectContainmentEList<Block>(Block.class, this, BlockdDiagramPackage.BDD__BLOCK);
		}
		return block;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<SharedAssociation> getShared() {
		if (shared == null) {
			shared = new EObjectContainmentEList<SharedAssociation>(SharedAssociation.class, this, BlockdDiagramPackage.BDD__SHARED);
		}
		return shared;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Generalization> getGeneral() {
		if (general == null) {
			general = new EObjectContainmentEList<Generalization>(Generalization.class, this, BlockdDiagramPackage.BDD__GENERAL);
		}
		return general;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Dependency> getDependency() {
		if (dependency == null) {
			dependency = new EObjectContainmentEList<Dependency>(Dependency.class, this, BlockdDiagramPackage.BDD__DEPENDENCY);
		}
		return dependency;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PartAssociation> getPartass() {
		if (partass == null) {
			partass = new EObjectContainmentEList<PartAssociation>(PartAssociation.class, this, BlockdDiagramPackage.BDD__PARTASS);
		}
		return partass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BlockdDiagramPackage.BDD__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case BlockdDiagramPackage.BDD__BLOCK:
				return ((InternalEList<?>)getBlock()).basicRemove(otherEnd, msgs);
			case BlockdDiagramPackage.BDD__SHARED:
				return ((InternalEList<?>)getShared()).basicRemove(otherEnd, msgs);
			case BlockdDiagramPackage.BDD__GENERAL:
				return ((InternalEList<?>)getGeneral()).basicRemove(otherEnd, msgs);
			case BlockdDiagramPackage.BDD__DEPENDENCY:
				return ((InternalEList<?>)getDependency()).basicRemove(otherEnd, msgs);
			case BlockdDiagramPackage.BDD__PARTASS:
				return ((InternalEList<?>)getPartass()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case BlockdDiagramPackage.BDD__BLOCK:
				return getBlock();
			case BlockdDiagramPackage.BDD__SHARED:
				return getShared();
			case BlockdDiagramPackage.BDD__GENERAL:
				return getGeneral();
			case BlockdDiagramPackage.BDD__DEPENDENCY:
				return getDependency();
			case BlockdDiagramPackage.BDD__PARTASS:
				return getPartass();
			case BlockdDiagramPackage.BDD__NAME:
				return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case BlockdDiagramPackage.BDD__BLOCK:
				getBlock().clear();
				getBlock().addAll((Collection<? extends Block>)newValue);
				return;
			case BlockdDiagramPackage.BDD__SHARED:
				getShared().clear();
				getShared().addAll((Collection<? extends SharedAssociation>)newValue);
				return;
			case BlockdDiagramPackage.BDD__GENERAL:
				getGeneral().clear();
				getGeneral().addAll((Collection<? extends Generalization>)newValue);
				return;
			case BlockdDiagramPackage.BDD__DEPENDENCY:
				getDependency().clear();
				getDependency().addAll((Collection<? extends Dependency>)newValue);
				return;
			case BlockdDiagramPackage.BDD__PARTASS:
				getPartass().clear();
				getPartass().addAll((Collection<? extends PartAssociation>)newValue);
				return;
			case BlockdDiagramPackage.BDD__NAME:
				setName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case BlockdDiagramPackage.BDD__BLOCK:
				getBlock().clear();
				return;
			case BlockdDiagramPackage.BDD__SHARED:
				getShared().clear();
				return;
			case BlockdDiagramPackage.BDD__GENERAL:
				getGeneral().clear();
				return;
			case BlockdDiagramPackage.BDD__DEPENDENCY:
				getDependency().clear();
				return;
			case BlockdDiagramPackage.BDD__PARTASS:
				getPartass().clear();
				return;
			case BlockdDiagramPackage.BDD__NAME:
				setName(NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case BlockdDiagramPackage.BDD__BLOCK:
				return block != null && !block.isEmpty();
			case BlockdDiagramPackage.BDD__SHARED:
				return shared != null && !shared.isEmpty();
			case BlockdDiagramPackage.BDD__GENERAL:
				return general != null && !general.isEmpty();
			case BlockdDiagramPackage.BDD__DEPENDENCY:
				return dependency != null && !dependency.isEmpty();
			case BlockdDiagramPackage.BDD__PARTASS:
				return partass != null && !partass.isEmpty();
			case BlockdDiagramPackage.BDD__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //BDDImpl
