/**
 */
package BlockdDiagram;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IBD</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link BlockdDiagram.IBD#getItemflow <em>Itemflow</em>}</li>
 *   <li>{@link BlockdDiagram.IBD#getPart <em>Part</em>}</li>
 * </ul>
 *
 * @see BlockdDiagram.BlockdDiagramPackage#getIBD()
 * @model
 * @generated
 */
public interface IBD extends Block {
	/**
	 * Returns the value of the '<em><b>Itemflow</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.ItemFlow}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Itemflow</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getIBD_Itemflow()
	 * @model containment="true"
	 * @generated
	 */
	EList<ItemFlow> getItemflow();

	/**
	 * Returns the value of the '<em><b>Part</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.Part}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Part</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getIBD_Part()
	 * @model containment="true"
	 * @generated
	 */
	EList<Part> getPart();

} // IBD
