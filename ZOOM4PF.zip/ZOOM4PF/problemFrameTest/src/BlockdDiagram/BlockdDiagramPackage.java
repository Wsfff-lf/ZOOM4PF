/**
 */
package BlockdDiagram;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see BlockdDiagram.BlockdDiagramFactory
 * @model kind="package"
 * @generated
 */
public interface BlockdDiagramPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "BlockdDiagram";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.gxnu.edu.re/BlockdDiagram";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "BlockdDiagram";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	BlockdDiagramPackage eINSTANCE = BlockdDiagram.impl.BlockdDiagramPackageImpl.init();

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.BDDImpl <em>BDD</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.BDDImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getBDD()
	 * @generated
	 */
	int BDD = 0;

	/**
	 * The feature id for the '<em><b>Block</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BDD__BLOCK = 0;

	/**
	 * The feature id for the '<em><b>Shared</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BDD__SHARED = 1;

	/**
	 * The feature id for the '<em><b>General</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BDD__GENERAL = 2;

	/**
	 * The feature id for the '<em><b>Dependency</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BDD__DEPENDENCY = 3;

	/**
	 * The feature id for the '<em><b>Partass</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BDD__PARTASS = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BDD__NAME = 5;

	/**
	 * The number of structural features of the '<em>BDD</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BDD_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>BDD</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BDD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.BlockImpl <em>Block</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.BlockImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getBlock()
	 * @generated
	 */
	int BLOCK = 1;

	/**
	 * The feature id for the '<em><b>Operations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK__OPERATIONS = 0;

	/**
	 * The feature id for the '<em><b>Propertys</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK__PROPERTYS = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK__NAME = 2;

	/**
	 * The feature id for the '<em><b>Part</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK__PART = 3;

	/**
	 * The feature id for the '<em><b>Itemflow</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK__ITEMFLOW = 4;

	/**
	 * The feature id for the '<em><b>Port</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK__PORT = 5;

	/**
	 * The feature id for the '<em><b>Connect</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK__CONNECT = 6;

	/**
	 * The number of structural features of the '<em>Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.OperationsImpl <em>Operations</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.OperationsImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getOperations()
	 * @generated
	 */
	int OPERATIONS = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATIONS__NAME = 0;

	/**
	 * The number of structural features of the '<em>Operations</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATIONS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Operations</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATIONS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.PropertysImpl <em>Propertys</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.PropertysImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPropertys()
	 * @generated
	 */
	int PROPERTYS = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTYS__NAME = 0;

	/**
	 * The number of structural features of the '<em>Propertys</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTYS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Propertys</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTYS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.SharedAssociationImpl <em>Shared Association</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.SharedAssociationImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getSharedAssociation()
	 * @generated
	 */
	int SHARED_ASSOCIATION = 4;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARED_ASSOCIATION__SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARED_ASSOCIATION__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARED_ASSOCIATION__NAME = 2;

	/**
	 * The number of structural features of the '<em>Shared Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARED_ASSOCIATION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Shared Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARED_ASSOCIATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.GeneralizationImpl <em>Generalization</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.GeneralizationImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getGeneralization()
	 * @generated
	 */
	int GENERALIZATION = 5;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION__SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION__NAME = 2;

	/**
	 * The number of structural features of the '<em>Generalization</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Generalization</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.DependencyImpl <em>Dependency</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.DependencyImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getDependency()
	 * @generated
	 */
	int DEPENDENCY = 6;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY__SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY__NAME = 2;

	/**
	 * The number of structural features of the '<em>Dependency</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Dependency</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.PartAssociationImpl <em>Part Association</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.PartAssociationImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPartAssociation()
	 * @generated
	 */
	int PART_ASSOCIATION = 7;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PART_ASSOCIATION__TARGET = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PART_ASSOCIATION__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PART_ASSOCIATION__NAME = 2;

	/**
	 * The number of structural features of the '<em>Part Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PART_ASSOCIATION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Part Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PART_ASSOCIATION_OPERATION_COUNT = 0;


	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.PartImpl <em>Part</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.PartImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPart()
	 * @generated
	 */
	int PART = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PART__NAME = 0;

	/**
	 * The feature id for the '<em><b>Part Kind</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PART__PART_KIND = 1;

	/**
	 * The feature id for the '<em><b>Part2port</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PART__PART2PORT = 2;

	/**
	 * The feature id for the '<em><b>Subpart</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PART__SUBPART = 3;

	/**
	 * The number of structural features of the '<em>Part</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PART_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Part</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PART_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.ConnectImpl <em>Connect</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.ConnectImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getConnect()
	 * @generated
	 */
	int CONNECT = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECT__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECT__TARGET = 2;

	/**
	 * The number of structural features of the '<em>Connect</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Connect</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.PortImpl <em>Port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.PortImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPort()
	 * @generated
	 */
	int PORT = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Port Kind</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__PORT_KIND = 1;

	/**
	 * The feature id for the '<em><b>Cmd</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__CMD = 2;

	/**
	 * The feature id for the '<em><b>Data</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__DATA = 3;

	/**
	 * The number of structural features of the '<em>Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.ItemFlowImpl <em>Item Flow</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.ItemFlowImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getItemFlow()
	 * @generated
	 */
	int ITEM_FLOW = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_FLOW__NAME = 0;

	/**
	 * The feature id for the '<em><b>Flow Kind</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_FLOW__FLOW_KIND = 1;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_FLOW__SOURCE = 2;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_FLOW__TARGET = 3;

	/**
	 * The number of structural features of the '<em>Item Flow</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_FLOW_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Item Flow</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_FLOW_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.CmdImpl <em>Cmd</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.CmdImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getCmd()
	 * @generated
	 */
	int CMD = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CMD__NAME = 0;

	/**
	 * The number of structural features of the '<em>Cmd</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CMD_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Cmd</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CMD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.impl.DataImpl <em>Data</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.impl.DataImpl
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getData()
	 * @generated
	 */
	int DATA = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA__NAME = 0;

	/**
	 * The number of structural features of the '<em>Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link BlockdDiagram.PortKind <em>Port Kind</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.PortKind
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPortKind()
	 * @generated
	 */
	int PORT_KIND = 14;

	/**
	 * The meta object id for the '{@link BlockdDiagram.PartKind <em>Part Kind</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.PartKind
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPartKind()
	 * @generated
	 */
	int PART_KIND = 15;

	/**
	 * The meta object id for the '{@link BlockdDiagram.FlowKind <em>Flow Kind</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see BlockdDiagram.FlowKind
	 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getFlowKind()
	 * @generated
	 */
	int FLOW_KIND = 16;


	/**
	 * Returns the meta object for class '{@link BlockdDiagram.BDD <em>BDD</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>BDD</em>'.
	 * @see BlockdDiagram.BDD
	 * @generated
	 */
	EClass getBDD();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.BDD#getBlock <em>Block</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Block</em>'.
	 * @see BlockdDiagram.BDD#getBlock()
	 * @see #getBDD()
	 * @generated
	 */
	EReference getBDD_Block();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.BDD#getShared <em>Shared</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Shared</em>'.
	 * @see BlockdDiagram.BDD#getShared()
	 * @see #getBDD()
	 * @generated
	 */
	EReference getBDD_Shared();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.BDD#getGeneral <em>General</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>General</em>'.
	 * @see BlockdDiagram.BDD#getGeneral()
	 * @see #getBDD()
	 * @generated
	 */
	EReference getBDD_General();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.BDD#getDependency <em>Dependency</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dependency</em>'.
	 * @see BlockdDiagram.BDD#getDependency()
	 * @see #getBDD()
	 * @generated
	 */
	EReference getBDD_Dependency();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.BDD#getPartass <em>Partass</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Partass</em>'.
	 * @see BlockdDiagram.BDD#getPartass()
	 * @see #getBDD()
	 * @generated
	 */
	EReference getBDD_Partass();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.BDD#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.BDD#getName()
	 * @see #getBDD()
	 * @generated
	 */
	EAttribute getBDD_Name();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.Block <em>Block</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Block</em>'.
	 * @see BlockdDiagram.Block
	 * @generated
	 */
	EClass getBlock();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.Block#getOperations <em>Operations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operations</em>'.
	 * @see BlockdDiagram.Block#getOperations()
	 * @see #getBlock()
	 * @generated
	 */
	EReference getBlock_Operations();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.Block#getPropertys <em>Propertys</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Propertys</em>'.
	 * @see BlockdDiagram.Block#getPropertys()
	 * @see #getBlock()
	 * @generated
	 */
	EReference getBlock_Propertys();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Block#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.Block#getName()
	 * @see #getBlock()
	 * @generated
	 */
	EAttribute getBlock_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.Block#getPart <em>Part</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Part</em>'.
	 * @see BlockdDiagram.Block#getPart()
	 * @see #getBlock()
	 * @generated
	 */
	EReference getBlock_Part();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.Block#getItemflow <em>Itemflow</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Itemflow</em>'.
	 * @see BlockdDiagram.Block#getItemflow()
	 * @see #getBlock()
	 * @generated
	 */
	EReference getBlock_Itemflow();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.Block#getPort <em>Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Port</em>'.
	 * @see BlockdDiagram.Block#getPort()
	 * @see #getBlock()
	 * @generated
	 */
	EReference getBlock_Port();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.Block#getConnect <em>Connect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Connect</em>'.
	 * @see BlockdDiagram.Block#getConnect()
	 * @see #getBlock()
	 * @generated
	 */
	EReference getBlock_Connect();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.Operations <em>Operations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Operations</em>'.
	 * @see BlockdDiagram.Operations
	 * @generated
	 */
	EClass getOperations();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Operations#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.Operations#getName()
	 * @see #getOperations()
	 * @generated
	 */
	EAttribute getOperations_Name();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.Propertys <em>Propertys</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Propertys</em>'.
	 * @see BlockdDiagram.Propertys
	 * @generated
	 */
	EClass getPropertys();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Propertys#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.Propertys#getName()
	 * @see #getPropertys()
	 * @generated
	 */
	EAttribute getPropertys_Name();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.SharedAssociation <em>Shared Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Shared Association</em>'.
	 * @see BlockdDiagram.SharedAssociation
	 * @generated
	 */
	EClass getSharedAssociation();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.SharedAssociation#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see BlockdDiagram.SharedAssociation#getSource()
	 * @see #getSharedAssociation()
	 * @generated
	 */
	EReference getSharedAssociation_Source();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.SharedAssociation#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see BlockdDiagram.SharedAssociation#getTarget()
	 * @see #getSharedAssociation()
	 * @generated
	 */
	EReference getSharedAssociation_Target();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.SharedAssociation#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.SharedAssociation#getName()
	 * @see #getSharedAssociation()
	 * @generated
	 */
	EAttribute getSharedAssociation_Name();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.Generalization <em>Generalization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Generalization</em>'.
	 * @see BlockdDiagram.Generalization
	 * @generated
	 */
	EClass getGeneralization();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.Generalization#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see BlockdDiagram.Generalization#getSource()
	 * @see #getGeneralization()
	 * @generated
	 */
	EReference getGeneralization_Source();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.Generalization#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see BlockdDiagram.Generalization#getTarget()
	 * @see #getGeneralization()
	 * @generated
	 */
	EReference getGeneralization_Target();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Generalization#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.Generalization#getName()
	 * @see #getGeneralization()
	 * @generated
	 */
	EAttribute getGeneralization_Name();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.Dependency <em>Dependency</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dependency</em>'.
	 * @see BlockdDiagram.Dependency
	 * @generated
	 */
	EClass getDependency();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.Dependency#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see BlockdDiagram.Dependency#getSource()
	 * @see #getDependency()
	 * @generated
	 */
	EReference getDependency_Source();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.Dependency#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see BlockdDiagram.Dependency#getTarget()
	 * @see #getDependency()
	 * @generated
	 */
	EReference getDependency_Target();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Dependency#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.Dependency#getName()
	 * @see #getDependency()
	 * @generated
	 */
	EAttribute getDependency_Name();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.PartAssociation <em>Part Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Part Association</em>'.
	 * @see BlockdDiagram.PartAssociation
	 * @generated
	 */
	EClass getPartAssociation();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.PartAssociation#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see BlockdDiagram.PartAssociation#getTarget()
	 * @see #getPartAssociation()
	 * @generated
	 */
	EReference getPartAssociation_Target();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.PartAssociation#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see BlockdDiagram.PartAssociation#getSource()
	 * @see #getPartAssociation()
	 * @generated
	 */
	EReference getPartAssociation_Source();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.PartAssociation#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.PartAssociation#getName()
	 * @see #getPartAssociation()
	 * @generated
	 */
	EAttribute getPartAssociation_Name();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.Part <em>Part</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Part</em>'.
	 * @see BlockdDiagram.Part
	 * @generated
	 */
	EClass getPart();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Part#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.Part#getName()
	 * @see #getPart()
	 * @generated
	 */
	EAttribute getPart_Name();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Part#getPartKind <em>Part Kind</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Part Kind</em>'.
	 * @see BlockdDiagram.Part#getPartKind()
	 * @see #getPart()
	 * @generated
	 */
	EAttribute getPart_PartKind();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.Part#getPart2port <em>Part2port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Part2port</em>'.
	 * @see BlockdDiagram.Part#getPart2port()
	 * @see #getPart()
	 * @generated
	 */
	EReference getPart_Part2port();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.Part#getSubpart <em>Subpart</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Subpart</em>'.
	 * @see BlockdDiagram.Part#getSubpart()
	 * @see #getPart()
	 * @generated
	 */
	EReference getPart_Subpart();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.Connect <em>Connect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connect</em>'.
	 * @see BlockdDiagram.Connect
	 * @generated
	 */
	EClass getConnect();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Connect#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.Connect#getName()
	 * @see #getConnect()
	 * @generated
	 */
	EAttribute getConnect_Name();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.Connect#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see BlockdDiagram.Connect#getSource()
	 * @see #getConnect()
	 * @generated
	 */
	EReference getConnect_Source();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.Connect#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see BlockdDiagram.Connect#getTarget()
	 * @see #getConnect()
	 * @generated
	 */
	EReference getConnect_Target();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.Port <em>Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port</em>'.
	 * @see BlockdDiagram.Port
	 * @generated
	 */
	EClass getPort();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Port#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.Port#getName()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_Name();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Port#getPortKind <em>Port Kind</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Port Kind</em>'.
	 * @see BlockdDiagram.Port#getPortKind()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_PortKind();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.Port#getCmd <em>Cmd</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cmd</em>'.
	 * @see BlockdDiagram.Port#getCmd()
	 * @see #getPort()
	 * @generated
	 */
	EReference getPort_Cmd();

	/**
	 * Returns the meta object for the containment reference list '{@link BlockdDiagram.Port#getData <em>Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Data</em>'.
	 * @see BlockdDiagram.Port#getData()
	 * @see #getPort()
	 * @generated
	 */
	EReference getPort_Data();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.ItemFlow <em>Item Flow</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Item Flow</em>'.
	 * @see BlockdDiagram.ItemFlow
	 * @generated
	 */
	EClass getItemFlow();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.ItemFlow#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.ItemFlow#getName()
	 * @see #getItemFlow()
	 * @generated
	 */
	EAttribute getItemFlow_Name();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.ItemFlow#getFlowKind <em>Flow Kind</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Flow Kind</em>'.
	 * @see BlockdDiagram.ItemFlow#getFlowKind()
	 * @see #getItemFlow()
	 * @generated
	 */
	EAttribute getItemFlow_FlowKind();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.ItemFlow#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see BlockdDiagram.ItemFlow#getSource()
	 * @see #getItemFlow()
	 * @generated
	 */
	EReference getItemFlow_Source();

	/**
	 * Returns the meta object for the reference '{@link BlockdDiagram.ItemFlow#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see BlockdDiagram.ItemFlow#getTarget()
	 * @see #getItemFlow()
	 * @generated
	 */
	EReference getItemFlow_Target();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.Cmd <em>Cmd</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cmd</em>'.
	 * @see BlockdDiagram.Cmd
	 * @generated
	 */
	EClass getCmd();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Cmd#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.Cmd#getName()
	 * @see #getCmd()
	 * @generated
	 */
	EAttribute getCmd_Name();

	/**
	 * Returns the meta object for class '{@link BlockdDiagram.Data <em>Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Data</em>'.
	 * @see BlockdDiagram.Data
	 * @generated
	 */
	EClass getData();

	/**
	 * Returns the meta object for the attribute '{@link BlockdDiagram.Data#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see BlockdDiagram.Data#getName()
	 * @see #getData()
	 * @generated
	 */
	EAttribute getData_Name();

	/**
	 * Returns the meta object for enum '{@link BlockdDiagram.PortKind <em>Port Kind</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Port Kind</em>'.
	 * @see BlockdDiagram.PortKind
	 * @generated
	 */
	EEnum getPortKind();

	/**
	 * Returns the meta object for enum '{@link BlockdDiagram.PartKind <em>Part Kind</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Part Kind</em>'.
	 * @see BlockdDiagram.PartKind
	 * @generated
	 */
	EEnum getPartKind();

	/**
	 * Returns the meta object for enum '{@link BlockdDiagram.FlowKind <em>Flow Kind</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Flow Kind</em>'.
	 * @see BlockdDiagram.FlowKind
	 * @generated
	 */
	EEnum getFlowKind();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	BlockdDiagramFactory getBlockdDiagramFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.BDDImpl <em>BDD</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.BDDImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getBDD()
		 * @generated
		 */
		EClass BDD = eINSTANCE.getBDD();

		/**
		 * The meta object literal for the '<em><b>Block</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BDD__BLOCK = eINSTANCE.getBDD_Block();

		/**
		 * The meta object literal for the '<em><b>Shared</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BDD__SHARED = eINSTANCE.getBDD_Shared();

		/**
		 * The meta object literal for the '<em><b>General</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BDD__GENERAL = eINSTANCE.getBDD_General();

		/**
		 * The meta object literal for the '<em><b>Dependency</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BDD__DEPENDENCY = eINSTANCE.getBDD_Dependency();

		/**
		 * The meta object literal for the '<em><b>Partass</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BDD__PARTASS = eINSTANCE.getBDD_Partass();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BDD__NAME = eINSTANCE.getBDD_Name();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.BlockImpl <em>Block</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.BlockImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getBlock()
		 * @generated
		 */
		EClass BLOCK = eINSTANCE.getBlock();

		/**
		 * The meta object literal for the '<em><b>Operations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BLOCK__OPERATIONS = eINSTANCE.getBlock_Operations();

		/**
		 * The meta object literal for the '<em><b>Propertys</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BLOCK__PROPERTYS = eINSTANCE.getBlock_Propertys();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BLOCK__NAME = eINSTANCE.getBlock_Name();

		/**
		 * The meta object literal for the '<em><b>Part</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BLOCK__PART = eINSTANCE.getBlock_Part();

		/**
		 * The meta object literal for the '<em><b>Itemflow</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BLOCK__ITEMFLOW = eINSTANCE.getBlock_Itemflow();

		/**
		 * The meta object literal for the '<em><b>Port</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BLOCK__PORT = eINSTANCE.getBlock_Port();

		/**
		 * The meta object literal for the '<em><b>Connect</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BLOCK__CONNECT = eINSTANCE.getBlock_Connect();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.OperationsImpl <em>Operations</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.OperationsImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getOperations()
		 * @generated
		 */
		EClass OPERATIONS = eINSTANCE.getOperations();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPERATIONS__NAME = eINSTANCE.getOperations_Name();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.PropertysImpl <em>Propertys</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.PropertysImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPropertys()
		 * @generated
		 */
		EClass PROPERTYS = eINSTANCE.getPropertys();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTYS__NAME = eINSTANCE.getPropertys_Name();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.SharedAssociationImpl <em>Shared Association</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.SharedAssociationImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getSharedAssociation()
		 * @generated
		 */
		EClass SHARED_ASSOCIATION = eINSTANCE.getSharedAssociation();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHARED_ASSOCIATION__SOURCE = eINSTANCE.getSharedAssociation_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHARED_ASSOCIATION__TARGET = eINSTANCE.getSharedAssociation_Target();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHARED_ASSOCIATION__NAME = eINSTANCE.getSharedAssociation_Name();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.GeneralizationImpl <em>Generalization</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.GeneralizationImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getGeneralization()
		 * @generated
		 */
		EClass GENERALIZATION = eINSTANCE.getGeneralization();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GENERALIZATION__SOURCE = eINSTANCE.getGeneralization_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GENERALIZATION__TARGET = eINSTANCE.getGeneralization_Target();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GENERALIZATION__NAME = eINSTANCE.getGeneralization_Name();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.DependencyImpl <em>Dependency</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.DependencyImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getDependency()
		 * @generated
		 */
		EClass DEPENDENCY = eINSTANCE.getDependency();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPENDENCY__SOURCE = eINSTANCE.getDependency_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPENDENCY__TARGET = eINSTANCE.getDependency_Target();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPENDENCY__NAME = eINSTANCE.getDependency_Name();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.PartAssociationImpl <em>Part Association</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.PartAssociationImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPartAssociation()
		 * @generated
		 */
		EClass PART_ASSOCIATION = eINSTANCE.getPartAssociation();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PART_ASSOCIATION__TARGET = eINSTANCE.getPartAssociation_Target();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PART_ASSOCIATION__SOURCE = eINSTANCE.getPartAssociation_Source();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PART_ASSOCIATION__NAME = eINSTANCE.getPartAssociation_Name();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.PartImpl <em>Part</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.PartImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPart()
		 * @generated
		 */
		EClass PART = eINSTANCE.getPart();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PART__NAME = eINSTANCE.getPart_Name();

		/**
		 * The meta object literal for the '<em><b>Part Kind</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PART__PART_KIND = eINSTANCE.getPart_PartKind();

		/**
		 * The meta object literal for the '<em><b>Part2port</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PART__PART2PORT = eINSTANCE.getPart_Part2port();

		/**
		 * The meta object literal for the '<em><b>Subpart</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PART__SUBPART = eINSTANCE.getPart_Subpart();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.ConnectImpl <em>Connect</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.ConnectImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getConnect()
		 * @generated
		 */
		EClass CONNECT = eINSTANCE.getConnect();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONNECT__NAME = eINSTANCE.getConnect_Name();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECT__SOURCE = eINSTANCE.getConnect_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECT__TARGET = eINSTANCE.getConnect_Target();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.PortImpl <em>Port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.PortImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPort()
		 * @generated
		 */
		EClass PORT = eINSTANCE.getPort();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__NAME = eINSTANCE.getPort_Name();

		/**
		 * The meta object literal for the '<em><b>Port Kind</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__PORT_KIND = eINSTANCE.getPort_PortKind();

		/**
		 * The meta object literal for the '<em><b>Cmd</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PORT__CMD = eINSTANCE.getPort_Cmd();

		/**
		 * The meta object literal for the '<em><b>Data</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PORT__DATA = eINSTANCE.getPort_Data();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.ItemFlowImpl <em>Item Flow</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.ItemFlowImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getItemFlow()
		 * @generated
		 */
		EClass ITEM_FLOW = eINSTANCE.getItemFlow();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ITEM_FLOW__NAME = eINSTANCE.getItemFlow_Name();

		/**
		 * The meta object literal for the '<em><b>Flow Kind</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ITEM_FLOW__FLOW_KIND = eINSTANCE.getItemFlow_FlowKind();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ITEM_FLOW__SOURCE = eINSTANCE.getItemFlow_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ITEM_FLOW__TARGET = eINSTANCE.getItemFlow_Target();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.CmdImpl <em>Cmd</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.CmdImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getCmd()
		 * @generated
		 */
		EClass CMD = eINSTANCE.getCmd();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CMD__NAME = eINSTANCE.getCmd_Name();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.impl.DataImpl <em>Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.impl.DataImpl
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getData()
		 * @generated
		 */
		EClass DATA = eINSTANCE.getData();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA__NAME = eINSTANCE.getData_Name();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.PortKind <em>Port Kind</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.PortKind
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPortKind()
		 * @generated
		 */
		EEnum PORT_KIND = eINSTANCE.getPortKind();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.PartKind <em>Part Kind</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.PartKind
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getPartKind()
		 * @generated
		 */
		EEnum PART_KIND = eINSTANCE.getPartKind();

		/**
		 * The meta object literal for the '{@link BlockdDiagram.FlowKind <em>Flow Kind</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see BlockdDiagram.FlowKind
		 * @see BlockdDiagram.impl.BlockdDiagramPackageImpl#getFlowKind()
		 * @generated
		 */
		EEnum FLOW_KIND = eINSTANCE.getFlowKind();

	}

} //BlockdDiagramPackage
