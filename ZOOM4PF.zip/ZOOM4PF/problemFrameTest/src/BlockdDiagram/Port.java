/**
 */
package BlockdDiagram;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link BlockdDiagram.Port#getName <em>Name</em>}</li>
 *   <li>{@link BlockdDiagram.Port#getPortKind <em>Port Kind</em>}</li>
 *   <li>{@link BlockdDiagram.Port#getCmd <em>Cmd</em>}</li>
 *   <li>{@link BlockdDiagram.Port#getData <em>Data</em>}</li>
 * </ul>
 *
 * @see BlockdDiagram.BlockdDiagramPackage#getPort()
 * @model
 * @generated
 */
public interface Port extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see BlockdDiagram.BlockdDiagramPackage#getPort_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link BlockdDiagram.Port#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Port Kind</b></em>' attribute.
	 * The literals are from the enumeration {@link BlockdDiagram.PortKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port Kind</em>' attribute.
	 * @see BlockdDiagram.PortKind
	 * @see #setPortKind(PortKind)
	 * @see BlockdDiagram.BlockdDiagramPackage#getPort_PortKind()
	 * @model
	 * @generated
	 */
	PortKind getPortKind();

	/**
	 * Sets the value of the '{@link BlockdDiagram.Port#getPortKind <em>Port Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Port Kind</em>' attribute.
	 * @see BlockdDiagram.PortKind
	 * @see #getPortKind()
	 * @generated
	 */
	void setPortKind(PortKind value);

	/**
	 * Returns the value of the '<em><b>Cmd</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.Cmd}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cmd</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getPort_Cmd()
	 * @model containment="true"
	 * @generated
	 */
	EList<Cmd> getCmd();

	/**
	 * Returns the value of the '<em><b>Data</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.Data}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getPort_Data()
	 * @model containment="true"
	 * @generated
	 */
	EList<Data> getData();

} // Port
