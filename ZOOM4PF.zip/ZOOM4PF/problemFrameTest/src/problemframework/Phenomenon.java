/**
 */
package problemframework;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Phenomenon</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link problemframework.Phenomenon#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.Phenomenon#isIsShared <em>Is Shared</em>}</li>
 *   <li>{@link problemframework.Phenomenon#getBelongTo <em>Belong To</em>}</li>
 *   <li>{@link problemframework.Phenomenon#getObservedBy <em>Observed By</em>}</li>
 *   <li>{@link problemframework.Phenomenon#getTargettodomain <em>Targettodomain</em>}</li>
 *   <li>{@link problemframework.Phenomenon#getSourcefromdomain <em>Sourcefromdomain</em>}</li>
 * </ul>
 *
 * @see problemframework.ProblemframeworkPackage#getPhenomenon()
 * @model
 * @generated
 */
public interface Phenomenon extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see problemframework.ProblemframeworkPackage#getPhenomenon_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link problemframework.Phenomenon#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Is Shared</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Shared</em>' attribute.
	 * @see #setIsShared(boolean)
	 * @see problemframework.ProblemframeworkPackage#getPhenomenon_IsShared()
	 * @model
	 * @generated
	 */
	boolean isIsShared();

	/**
	 * Sets the value of the '{@link problemframework.Phenomenon#isIsShared <em>Is Shared</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Shared</em>' attribute.
	 * @see #isIsShared()
	 * @generated
	 */
	void setIsShared(boolean value);

	/**
	 * Returns the value of the '<em><b>Belong To</b></em>' reference list.
	 * The list contents are of type {@link problemframework.Domain}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Belong To</em>' reference list.
	 * @see problemframework.ProblemframeworkPackage#getPhenomenon_BelongTo()
	 * @model
	 * @generated
	 */
	EList<Domain> getBelongTo();

	/**
	 * Returns the value of the '<em><b>Observed By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Observed By</em>' reference.
	 * @see #setObservedBy(Machine)
	 * @see problemframework.ProblemframeworkPackage#getPhenomenon_ObservedBy()
	 * @model
	 * @generated
	 */
	Machine getObservedBy();

	/**
	 * Sets the value of the '{@link problemframework.Phenomenon#getObservedBy <em>Observed By</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Observed By</em>' reference.
	 * @see #getObservedBy()
	 * @generated
	 */
	void setObservedBy(Machine value);

	/**
	 * Returns the value of the '<em><b>Targettodomain</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Targettodomain</em>' reference.
	 * @see #setTargettodomain(Domain)
	 * @see problemframework.ProblemframeworkPackage#getPhenomenon_Targettodomain()
	 * @model
	 * @generated
	 */
	Domain getTargettodomain();

	/**
	 * Sets the value of the '{@link problemframework.Phenomenon#getTargettodomain <em>Targettodomain</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Targettodomain</em>' reference.
	 * @see #getTargettodomain()
	 * @generated
	 */
	void setTargettodomain(Domain value);

	/**
	 * Returns the value of the '<em><b>Sourcefromdomain</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sourcefromdomain</em>' reference.
	 * @see #setSourcefromdomain(Domain)
	 * @see problemframework.ProblemframeworkPackage#getPhenomenon_Sourcefromdomain()
	 * @model
	 * @generated
	 */
	Domain getSourcefromdomain();

	/**
	 * Sets the value of the '{@link problemframework.Phenomenon#getSourcefromdomain <em>Sourcefromdomain</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sourcefromdomain</em>' reference.
	 * @see #getSourcefromdomain()
	 * @generated
	 */
	void setSourcefromdomain(Domain value);

} // Phenomenon
