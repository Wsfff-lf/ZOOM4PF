/**
 */
package problemframework;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Machine</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link problemframework.Machine#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.Machine#getControl <em>Control</em>}</li>
 *   <li>{@link problemframework.Machine#getSubmachine <em>Submachine</em>}</li>
 * </ul>
 *
 * @see problemframework.ProblemframeworkPackage#getMachine()
 * @model
 * @generated
 */
public interface Machine extends SubPF {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see problemframework.ProblemframeworkPackage#getMachine_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link problemframework.Machine#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Control</b></em>' reference list.
	 * The list contents are of type {@link problemframework.Phenomenon}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Control</em>' reference list.
	 * @see problemframework.ProblemframeworkPackage#getMachine_Control()
	 * @model
	 * @generated
	 */
	EList<Phenomenon> getControl();

	/**
	 * Returns the value of the '<em><b>Submachine</b></em>' containment reference list.
	 * The list contents are of type {@link problemframework.SubPF}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Submachine</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getMachine_Submachine()
	 * @model containment="true"
	 * @generated
	 */
	EList<SubPF> getSubmachine();

} // Machine
