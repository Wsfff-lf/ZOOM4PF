/**
 */
package problemframework;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Requirement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link problemframework.Requirement#getReferTo <em>Refer To</em>}</li>
 *   <li>{@link problemframework.Requirement#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.Requirement#isIsInteraction <em>Is Interaction</em>}</li>
 *   <li>{@link problemframework.Requirement#isIsService <em>Is Service</em>}</li>
 *   <li>{@link problemframework.Requirement#isIsUseCase <em>Is Use Case</em>}</li>
 *   <li>{@link problemframework.Requirement#isIsThirdPartServices <em>Is Third Part Services</em>}</li>
 * </ul>
 *
 * @see problemframework.ProblemframeworkPackage#getRequirement()
 * @model
 * @generated
 */
public interface Requirement extends EObject {
	/**
	 * Returns the value of the '<em><b>Is Use Case</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Use Case</em>' attribute.
	 * @see #setIsUseCase(boolean)
	 * @see problemframework.ProblemframeworkPackage#getRequirement_IsUseCase()
	 * @model
	 * @generated
	 */
	boolean isIsUseCase();

	/**
	 * Sets the value of the '{@link problemframework.Requirement#isIsUseCase <em>Is Use Case</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Use Case</em>' attribute.
	 * @see #isIsUseCase()
	 * @generated
	 */
	void setIsUseCase(boolean value);

	/**
	 * Returns the value of the '<em><b>Is Service</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Service</em>' attribute.
	 * @see #setIsService(boolean)
	 * @see problemframework.ProblemframeworkPackage#getRequirement_IsService()
	 * @model
	 * @generated
	 */
	boolean isIsService();

	/**
	 * Sets the value of the '{@link problemframework.Requirement#isIsService <em>Is Service</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Service</em>' attribute.
	 * @see #isIsService()
	 * @generated
	 */
	void setIsService(boolean value);

	/**
	 * Returns the value of the '<em><b>Is Interaction</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Interaction</em>' attribute.
	 * @see #setIsInteraction(boolean)
	 * @see problemframework.ProblemframeworkPackage#getRequirement_IsInteraction()
	 * @model
	 * @generated
	 */
	boolean isIsInteraction();

	/**
	 * Sets the value of the '{@link problemframework.Requirement#isIsInteraction <em>Is Interaction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Interaction</em>' attribute.
	 * @see #isIsInteraction()
	 * @generated
	 */
	void setIsInteraction(boolean value);

	/**
	 * Returns the value of the '<em><b>Is Third Part Services</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Third Part Services</em>' attribute.
	 * @see #setIsThirdPartServices(boolean)
	 * @see problemframework.ProblemframeworkPackage#getRequirement_IsThirdPartServices()
	 * @model
	 * @generated
	 */
	boolean isIsThirdPartServices();

	/**
	 * Sets the value of the '{@link problemframework.Requirement#isIsThirdPartServices <em>Is Third Part Services</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Third Part Services</em>' attribute.
	 * @see #isIsThirdPartServices()
	 * @generated
	 */
	void setIsThirdPartServices(boolean value);

	/**
	 * Returns the value of the '<em><b>Refer To</b></em>' reference list.
	 * The list contents are of type {@link problemframework.Phenomenon}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Refer To</em>' reference list.
	 * @see problemframework.ProblemframeworkPackage#getRequirement_ReferTo()
	 * @model
	 * @generated
	 */
	EList<Phenomenon> getReferTo();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see problemframework.ProblemframeworkPackage#getRequirement_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link problemframework.Requirement#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // Requirement
