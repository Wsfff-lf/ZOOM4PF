/**
 */
package problemframework;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub PF</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see problemframework.ProblemframeworkPackage#getSubPF()
 * @model abstract="true"
 * @generated
 */
public interface SubPF extends EObject {
} // SubPF
