/**
 */
package problemframework;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see problemframework.ProblemframeworkFactory
 * @model kind="package"
 * @generated
 */
public interface ProblemframeworkPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "problemframework";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.gxnu.edu.re/problemframework";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "problemframework";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ProblemframeworkPackage eINSTANCE = problemframework.impl.ProblemframeworkPackageImpl.init();

	/**
	 * The meta object id for the '{@link problemframework.impl.SubPFImpl <em>Sub PF</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see problemframework.impl.SubPFImpl
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getSubPF()
	 * @generated
	 */
	int SUB_PF = 8;

	/**
	 * The number of structural features of the '<em>Sub PF</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUB_PF_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Sub PF</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUB_PF_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link problemframework.impl.ProblemFrameworkImpl <em>Problem Framework</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see problemframework.impl.ProblemFrameworkImpl
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getProblemFramework()
	 * @generated
	 */
	int PROBLEM_FRAMEWORK = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBLEM_FRAMEWORK__NAME = SUB_PF_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Domain</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBLEM_FRAMEWORK__DOMAIN = SUB_PF_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Machine</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBLEM_FRAMEWORK__MACHINE = SUB_PF_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Phenomenon</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBLEM_FRAMEWORK__PHENOMENON = SUB_PF_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Requirement</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBLEM_FRAMEWORK__REQUIREMENT = SUB_PF_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Reference</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBLEM_FRAMEWORK__REFERENCE = SUB_PF_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Exstate</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBLEM_FRAMEWORK__EXSTATE = SUB_PF_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Exbdd</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBLEM_FRAMEWORK__EXBDD = SUB_PF_FEATURE_COUNT + 7;

	/**
	 * The number of structural features of the '<em>Problem Framework</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBLEM_FRAMEWORK_FEATURE_COUNT = SUB_PF_FEATURE_COUNT + 8;

	/**
	 * The number of operations of the '<em>Problem Framework</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROBLEM_FRAMEWORK_OPERATION_COUNT = SUB_PF_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link problemframework.impl.MachineImpl <em>Machine</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see problemframework.impl.MachineImpl
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getMachine()
	 * @generated
	 */
	int MACHINE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MACHINE__NAME = SUB_PF_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Control</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MACHINE__CONTROL = SUB_PF_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Submachine</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MACHINE__SUBMACHINE = SUB_PF_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Machine</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MACHINE_FEATURE_COUNT = SUB_PF_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Machine</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MACHINE_OPERATION_COUNT = SUB_PF_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link problemframework.impl.DomainImpl <em>Domain</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see problemframework.impl.DomainImpl
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getDomain()
	 * @generated
	 */
	int DOMAIN = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN__NAME = 0;

	/**
	 * The feature id for the '<em><b>Addstate</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN__ADDSTATE = 1;

	/**
	 * The feature id for the '<em><b>Addbdd</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN__ADDBDD = 2;

	/**
	 * The feature id for the '<em><b>Is Class</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN__IS_CLASS = 3;

	/**
	 * The feature id for the '<em><b>Is Actor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN__IS_ACTOR = 4;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN__TYPE = 5;

	/**
	 * The number of structural features of the '<em>Domain</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Domain</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMAIN_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link problemframework.impl.PhenomenonImpl <em>Phenomenon</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see problemframework.impl.PhenomenonImpl
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getPhenomenon()
	 * @generated
	 */
	int PHENOMENON = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHENOMENON__NAME = 0;

	/**
	 * The feature id for the '<em><b>Is Shared</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHENOMENON__IS_SHARED = 1;

	/**
	 * The feature id for the '<em><b>Belong To</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHENOMENON__BELONG_TO = 2;

	/**
	 * The feature id for the '<em><b>Observed By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHENOMENON__OBSERVED_BY = 3;

	/**
	 * The feature id for the '<em><b>Targettodomain</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHENOMENON__TARGETTODOMAIN = 4;

	/**
	 * The feature id for the '<em><b>Sourcefromdomain</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHENOMENON__SOURCEFROMDOMAIN = 5;

	/**
	 * The number of structural features of the '<em>Phenomenon</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHENOMENON_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Phenomenon</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHENOMENON_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link problemframework.impl.RequirementImpl <em>Requirement</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see problemframework.impl.RequirementImpl
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getRequirement()
	 * @generated
	 */
	int REQUIREMENT = 4;

	/**
	 * The feature id for the '<em><b>Refer To</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT__REFER_TO = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT__NAME = 1;

	/**
	 * The feature id for the '<em><b>Is Interaction</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT__IS_INTERACTION = 2;

	/**
	 * The feature id for the '<em><b>Is Service</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT__IS_SERVICE = 3;

	/**
	 * The feature id for the '<em><b>Is Use Case</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT__IS_USE_CASE = 4;

	/**
	 * The feature id for the '<em><b>Is Third Part Services</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT__IS_THIRD_PART_SERVICES = 5;

	/**
	 * The number of structural features of the '<em>Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link problemframework.impl.ReferenceImpl <em>Reference</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see problemframework.impl.ReferenceImpl
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getReference()
	 * @generated
	 */
	int REFERENCE = 5;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Reference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Reference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link problemframework.impl.RequirementReferenceImpl <em>Requirement Reference</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see problemframework.impl.RequirementReferenceImpl
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getRequirementReference()
	 * @generated
	 */
	int REQUIREMENT_REFERENCE = 6;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_REFERENCE__SOURCE = REFERENCE__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_REFERENCE__TARGET = REFERENCE__TARGET;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_REFERENCE__NAME = REFERENCE__NAME;

	/**
	 * The number of structural features of the '<em>Requirement Reference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_REFERENCE_FEATURE_COUNT = REFERENCE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Requirement Reference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_REFERENCE_OPERATION_COUNT = REFERENCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link problemframework.impl.RequirementConstraintImpl <em>Requirement Constraint</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see problemframework.impl.RequirementConstraintImpl
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getRequirementConstraint()
	 * @generated
	 */
	int REQUIREMENT_CONSTRAINT = 7;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_CONSTRAINT__SOURCE = REFERENCE__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_CONSTRAINT__TARGET = REFERENCE__TARGET;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_CONSTRAINT__NAME = REFERENCE__NAME;

	/**
	 * The number of structural features of the '<em>Requirement Constraint</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_CONSTRAINT_FEATURE_COUNT = REFERENCE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Requirement Constraint</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIREMENT_CONSTRAINT_OPERATION_COUNT = REFERENCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link problemframework.attributeEnum <em>attribute Enum</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see problemframework.attributeEnum
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getattributeEnum()
	 * @generated
	 */
	int ATTRIBUTE_ENUM = 9;

	/**
	 * The meta object id for the '{@link problemframework.domainType <em>domain Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see problemframework.domainType
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getdomainType()
	 * @generated
	 */
	int DOMAIN_TYPE = 10;

	/**
	 * The meta object id for the '<em>Attribute String</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getAttributeString()
	 * @generated
	 */
	int ATTRIBUTE_STRING = 11;

	/**
	 * The meta object id for the '<em>Lexical Type</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.Object
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getLexicalType()
	 * @generated
	 */
	int LEXICAL_TYPE = 12;

	/**
	 * The meta object id for the '<em>Machine Type</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see problemframework.impl.ProblemframeworkPackageImpl#getMachineType()
	 * @generated
	 */
	int MACHINE_TYPE = 13;


	/**
	 * Returns the meta object for class '{@link problemframework.ProblemFramework <em>Problem Framework</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Problem Framework</em>'.
	 * @see problemframework.ProblemFramework
	 * @generated
	 */
	EClass getProblemFramework();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.ProblemFramework#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see problemframework.ProblemFramework#getName()
	 * @see #getProblemFramework()
	 * @generated
	 */
	EAttribute getProblemFramework_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link problemframework.ProblemFramework#getDomain <em>Domain</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Domain</em>'.
	 * @see problemframework.ProblemFramework#getDomain()
	 * @see #getProblemFramework()
	 * @generated
	 */
	EReference getProblemFramework_Domain();

	/**
	 * Returns the meta object for the containment reference list '{@link problemframework.ProblemFramework#getMachine <em>Machine</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Machine</em>'.
	 * @see problemframework.ProblemFramework#getMachine()
	 * @see #getProblemFramework()
	 * @generated
	 */
	EReference getProblemFramework_Machine();

	/**
	 * Returns the meta object for the containment reference list '{@link problemframework.ProblemFramework#getPhenomenon <em>Phenomenon</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Phenomenon</em>'.
	 * @see problemframework.ProblemFramework#getPhenomenon()
	 * @see #getProblemFramework()
	 * @generated
	 */
	EReference getProblemFramework_Phenomenon();

	/**
	 * Returns the meta object for the containment reference list '{@link problemframework.ProblemFramework#getRequirement <em>Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Requirement</em>'.
	 * @see problemframework.ProblemFramework#getRequirement()
	 * @see #getProblemFramework()
	 * @generated
	 */
	EReference getProblemFramework_Requirement();

	/**
	 * Returns the meta object for the containment reference list '{@link problemframework.ProblemFramework#getReference <em>Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Reference</em>'.
	 * @see problemframework.ProblemFramework#getReference()
	 * @see #getProblemFramework()
	 * @generated
	 */
	EReference getProblemFramework_Reference();

	/**
	 * Returns the meta object for the containment reference list '{@link problemframework.ProblemFramework#getExstate <em>Exstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Exstate</em>'.
	 * @see problemframework.ProblemFramework#getExstate()
	 * @see #getProblemFramework()
	 * @generated
	 */
	EReference getProblemFramework_Exstate();

	/**
	 * Returns the meta object for the containment reference list '{@link problemframework.ProblemFramework#getExbdd <em>Exbdd</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Exbdd</em>'.
	 * @see problemframework.ProblemFramework#getExbdd()
	 * @see #getProblemFramework()
	 * @generated
	 */
	EReference getProblemFramework_Exbdd();

	/**
	 * Returns the meta object for class '{@link problemframework.Machine <em>Machine</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Machine</em>'.
	 * @see problemframework.Machine
	 * @generated
	 */
	EClass getMachine();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Machine#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see problemframework.Machine#getName()
	 * @see #getMachine()
	 * @generated
	 */
	EAttribute getMachine_Name();

	/**
	 * Returns the meta object for the reference list '{@link problemframework.Machine#getControl <em>Control</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Control</em>'.
	 * @see problemframework.Machine#getControl()
	 * @see #getMachine()
	 * @generated
	 */
	EReference getMachine_Control();

	/**
	 * Returns the meta object for the containment reference list '{@link problemframework.Machine#getSubmachine <em>Submachine</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Submachine</em>'.
	 * @see problemframework.Machine#getSubmachine()
	 * @see #getMachine()
	 * @generated
	 */
	EReference getMachine_Submachine();

	/**
	 * Returns the meta object for class '{@link problemframework.Domain <em>Domain</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Domain</em>'.
	 * @see problemframework.Domain
	 * @generated
	 */
	EClass getDomain();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Domain#isIsClass <em>Is Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Class</em>'.
	 * @see problemframework.Domain#isIsClass()
	 * @see #getDomain()
	 * @generated
	 */
	EAttribute getDomain_IsClass();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Domain#isIsActor <em>Is Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Actor</em>'.
	 * @see problemframework.Domain#isIsActor()
	 * @see #getDomain()
	 * @generated
	 */
	EAttribute getDomain_IsActor();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Domain#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see problemframework.Domain#getType()
	 * @see #getDomain()
	 * @generated
	 */
	EAttribute getDomain_Type();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Domain#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see problemframework.Domain#getName()
	 * @see #getDomain()
	 * @generated
	 */
	EAttribute getDomain_Name();

	/**
	 * Returns the meta object for the reference list '{@link problemframework.Domain#getAddstate <em>Addstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Addstate</em>'.
	 * @see problemframework.Domain#getAddstate()
	 * @see #getDomain()
	 * @generated
	 */
	EReference getDomain_Addstate();

	/**
	 * Returns the meta object for the reference list '{@link problemframework.Domain#getAddbdd <em>Addbdd</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Addbdd</em>'.
	 * @see problemframework.Domain#getAddbdd()
	 * @see #getDomain()
	 * @generated
	 */
	EReference getDomain_Addbdd();

	/**
	 * Returns the meta object for class '{@link problemframework.Phenomenon <em>Phenomenon</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Phenomenon</em>'.
	 * @see problemframework.Phenomenon
	 * @generated
	 */
	EClass getPhenomenon();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Phenomenon#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see problemframework.Phenomenon#getName()
	 * @see #getPhenomenon()
	 * @generated
	 */
	EAttribute getPhenomenon_Name();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Phenomenon#isIsShared <em>Is Shared</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Shared</em>'.
	 * @see problemframework.Phenomenon#isIsShared()
	 * @see #getPhenomenon()
	 * @generated
	 */
	EAttribute getPhenomenon_IsShared();

	/**
	 * Returns the meta object for the reference list '{@link problemframework.Phenomenon#getBelongTo <em>Belong To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Belong To</em>'.
	 * @see problemframework.Phenomenon#getBelongTo()
	 * @see #getPhenomenon()
	 * @generated
	 */
	EReference getPhenomenon_BelongTo();

	/**
	 * Returns the meta object for the reference '{@link problemframework.Phenomenon#getObservedBy <em>Observed By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Observed By</em>'.
	 * @see problemframework.Phenomenon#getObservedBy()
	 * @see #getPhenomenon()
	 * @generated
	 */
	EReference getPhenomenon_ObservedBy();

	/**
	 * Returns the meta object for the reference '{@link problemframework.Phenomenon#getTargettodomain <em>Targettodomain</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Targettodomain</em>'.
	 * @see problemframework.Phenomenon#getTargettodomain()
	 * @see #getPhenomenon()
	 * @generated
	 */
	EReference getPhenomenon_Targettodomain();

	/**
	 * Returns the meta object for the reference '{@link problemframework.Phenomenon#getSourcefromdomain <em>Sourcefromdomain</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Sourcefromdomain</em>'.
	 * @see problemframework.Phenomenon#getSourcefromdomain()
	 * @see #getPhenomenon()
	 * @generated
	 */
	EReference getPhenomenon_Sourcefromdomain();

	/**
	 * Returns the meta object for class '{@link problemframework.Requirement <em>Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Requirement</em>'.
	 * @see problemframework.Requirement
	 * @generated
	 */
	EClass getRequirement();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Requirement#isIsUseCase <em>Is Use Case</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Use Case</em>'.
	 * @see problemframework.Requirement#isIsUseCase()
	 * @see #getRequirement()
	 * @generated
	 */
	EAttribute getRequirement_IsUseCase();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Requirement#isIsService <em>Is Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Service</em>'.
	 * @see problemframework.Requirement#isIsService()
	 * @see #getRequirement()
	 * @generated
	 */
	EAttribute getRequirement_IsService();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Requirement#isIsInteraction <em>Is Interaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Interaction</em>'.
	 * @see problemframework.Requirement#isIsInteraction()
	 * @see #getRequirement()
	 * @generated
	 */
	EAttribute getRequirement_IsInteraction();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Requirement#isIsThirdPartServices <em>Is Third Part Services</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Third Part Services</em>'.
	 * @see problemframework.Requirement#isIsThirdPartServices()
	 * @see #getRequirement()
	 * @generated
	 */
	EAttribute getRequirement_IsThirdPartServices();

	/**
	 * Returns the meta object for the reference list '{@link problemframework.Requirement#getReferTo <em>Refer To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Refer To</em>'.
	 * @see problemframework.Requirement#getReferTo()
	 * @see #getRequirement()
	 * @generated
	 */
	EReference getRequirement_ReferTo();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Requirement#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see problemframework.Requirement#getName()
	 * @see #getRequirement()
	 * @generated
	 */
	EAttribute getRequirement_Name();

	/**
	 * Returns the meta object for class '{@link problemframework.Reference <em>Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Reference</em>'.
	 * @see problemframework.Reference
	 * @generated
	 */
	EClass getReference();

	/**
	 * Returns the meta object for the reference '{@link problemframework.Reference#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see problemframework.Reference#getSource()
	 * @see #getReference()
	 * @generated
	 */
	EReference getReference_Source();

	/**
	 * Returns the meta object for the reference '{@link problemframework.Reference#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see problemframework.Reference#getTarget()
	 * @see #getReference()
	 * @generated
	 */
	EReference getReference_Target();

	/**
	 * Returns the meta object for the attribute '{@link problemframework.Reference#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see problemframework.Reference#getName()
	 * @see #getReference()
	 * @generated
	 */
	EAttribute getReference_Name();

	/**
	 * Returns the meta object for class '{@link problemframework.RequirementReference <em>Requirement Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Requirement Reference</em>'.
	 * @see problemframework.RequirementReference
	 * @generated
	 */
	EClass getRequirementReference();

	/**
	 * Returns the meta object for class '{@link problemframework.RequirementConstraint <em>Requirement Constraint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Requirement Constraint</em>'.
	 * @see problemframework.RequirementConstraint
	 * @generated
	 */
	EClass getRequirementConstraint();

	/**
	 * Returns the meta object for class '{@link problemframework.SubPF <em>Sub PF</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sub PF</em>'.
	 * @see problemframework.SubPF
	 * @generated
	 */
	EClass getSubPF();

	/**
	 * Returns the meta object for enum '{@link problemframework.attributeEnum <em>attribute Enum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>attribute Enum</em>'.
	 * @see problemframework.attributeEnum
	 * @generated
	 */
	EEnum getattributeEnum();

	/**
	 * Returns the meta object for enum '{@link problemframework.domainType <em>domain Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>domain Type</em>'.
	 * @see problemframework.domainType
	 * @generated
	 */
	EEnum getdomainType();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Attribute String</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Attribute String</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 * @generated
	 */
	EDataType getAttributeString();

	/**
	 * Returns the meta object for data type '{@link java.lang.Object <em>Lexical Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Lexical Type</em>'.
	 * @see java.lang.Object
	 * @model instanceClass="java.lang.Object"
	 * @generated
	 */
	EDataType getLexicalType();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Machine Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Machine Type</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 * @generated
	 */
	EDataType getMachineType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ProblemframeworkFactory getProblemframeworkFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link problemframework.impl.ProblemFrameworkImpl <em>Problem Framework</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see problemframework.impl.ProblemFrameworkImpl
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getProblemFramework()
		 * @generated
		 */
		EClass PROBLEM_FRAMEWORK = eINSTANCE.getProblemFramework();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROBLEM_FRAMEWORK__NAME = eINSTANCE.getProblemFramework_Name();

		/**
		 * The meta object literal for the '<em><b>Domain</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROBLEM_FRAMEWORK__DOMAIN = eINSTANCE.getProblemFramework_Domain();

		/**
		 * The meta object literal for the '<em><b>Machine</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROBLEM_FRAMEWORK__MACHINE = eINSTANCE.getProblemFramework_Machine();

		/**
		 * The meta object literal for the '<em><b>Phenomenon</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROBLEM_FRAMEWORK__PHENOMENON = eINSTANCE.getProblemFramework_Phenomenon();

		/**
		 * The meta object literal for the '<em><b>Requirement</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROBLEM_FRAMEWORK__REQUIREMENT = eINSTANCE.getProblemFramework_Requirement();

		/**
		 * The meta object literal for the '<em><b>Reference</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROBLEM_FRAMEWORK__REFERENCE = eINSTANCE.getProblemFramework_Reference();

		/**
		 * The meta object literal for the '<em><b>Exstate</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROBLEM_FRAMEWORK__EXSTATE = eINSTANCE.getProblemFramework_Exstate();

		/**
		 * The meta object literal for the '<em><b>Exbdd</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROBLEM_FRAMEWORK__EXBDD = eINSTANCE.getProblemFramework_Exbdd();

		/**
		 * The meta object literal for the '{@link problemframework.impl.MachineImpl <em>Machine</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see problemframework.impl.MachineImpl
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getMachine()
		 * @generated
		 */
		EClass MACHINE = eINSTANCE.getMachine();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MACHINE__NAME = eINSTANCE.getMachine_Name();

		/**
		 * The meta object literal for the '<em><b>Control</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MACHINE__CONTROL = eINSTANCE.getMachine_Control();

		/**
		 * The meta object literal for the '<em><b>Submachine</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MACHINE__SUBMACHINE = eINSTANCE.getMachine_Submachine();

		/**
		 * The meta object literal for the '{@link problemframework.impl.DomainImpl <em>Domain</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see problemframework.impl.DomainImpl
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getDomain()
		 * @generated
		 */
		EClass DOMAIN = eINSTANCE.getDomain();

		/**
		 * The meta object literal for the '<em><b>Is Class</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOMAIN__IS_CLASS = eINSTANCE.getDomain_IsClass();

		/**
		 * The meta object literal for the '<em><b>Is Actor</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOMAIN__IS_ACTOR = eINSTANCE.getDomain_IsActor();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOMAIN__TYPE = eINSTANCE.getDomain_Type();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOMAIN__NAME = eINSTANCE.getDomain_Name();

		/**
		 * The meta object literal for the '<em><b>Addstate</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN__ADDSTATE = eINSTANCE.getDomain_Addstate();

		/**
		 * The meta object literal for the '<em><b>Addbdd</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMAIN__ADDBDD = eINSTANCE.getDomain_Addbdd();

		/**
		 * The meta object literal for the '{@link problemframework.impl.PhenomenonImpl <em>Phenomenon</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see problemframework.impl.PhenomenonImpl
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getPhenomenon()
		 * @generated
		 */
		EClass PHENOMENON = eINSTANCE.getPhenomenon();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHENOMENON__NAME = eINSTANCE.getPhenomenon_Name();

		/**
		 * The meta object literal for the '<em><b>Is Shared</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHENOMENON__IS_SHARED = eINSTANCE.getPhenomenon_IsShared();

		/**
		 * The meta object literal for the '<em><b>Belong To</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHENOMENON__BELONG_TO = eINSTANCE.getPhenomenon_BelongTo();

		/**
		 * The meta object literal for the '<em><b>Observed By</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHENOMENON__OBSERVED_BY = eINSTANCE.getPhenomenon_ObservedBy();

		/**
		 * The meta object literal for the '<em><b>Targettodomain</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHENOMENON__TARGETTODOMAIN = eINSTANCE.getPhenomenon_Targettodomain();

		/**
		 * The meta object literal for the '<em><b>Sourcefromdomain</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHENOMENON__SOURCEFROMDOMAIN = eINSTANCE.getPhenomenon_Sourcefromdomain();

		/**
		 * The meta object literal for the '{@link problemframework.impl.RequirementImpl <em>Requirement</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see problemframework.impl.RequirementImpl
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getRequirement()
		 * @generated
		 */
		EClass REQUIREMENT = eINSTANCE.getRequirement();

		/**
		 * The meta object literal for the '<em><b>Is Use Case</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REQUIREMENT__IS_USE_CASE = eINSTANCE.getRequirement_IsUseCase();

		/**
		 * The meta object literal for the '<em><b>Is Service</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REQUIREMENT__IS_SERVICE = eINSTANCE.getRequirement_IsService();

		/**
		 * The meta object literal for the '<em><b>Is Interaction</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REQUIREMENT__IS_INTERACTION = eINSTANCE.getRequirement_IsInteraction();

		/**
		 * The meta object literal for the '<em><b>Is Third Part Services</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REQUIREMENT__IS_THIRD_PART_SERVICES = eINSTANCE.getRequirement_IsThirdPartServices();

		/**
		 * The meta object literal for the '<em><b>Refer To</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REQUIREMENT__REFER_TO = eINSTANCE.getRequirement_ReferTo();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REQUIREMENT__NAME = eINSTANCE.getRequirement_Name();

		/**
		 * The meta object literal for the '{@link problemframework.impl.ReferenceImpl <em>Reference</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see problemframework.impl.ReferenceImpl
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getReference()
		 * @generated
		 */
		EClass REFERENCE = eINSTANCE.getReference();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REFERENCE__SOURCE = eINSTANCE.getReference_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REFERENCE__TARGET = eINSTANCE.getReference_Target();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REFERENCE__NAME = eINSTANCE.getReference_Name();

		/**
		 * The meta object literal for the '{@link problemframework.impl.RequirementReferenceImpl <em>Requirement Reference</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see problemframework.impl.RequirementReferenceImpl
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getRequirementReference()
		 * @generated
		 */
		EClass REQUIREMENT_REFERENCE = eINSTANCE.getRequirementReference();

		/**
		 * The meta object literal for the '{@link problemframework.impl.RequirementConstraintImpl <em>Requirement Constraint</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see problemframework.impl.RequirementConstraintImpl
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getRequirementConstraint()
		 * @generated
		 */
		EClass REQUIREMENT_CONSTRAINT = eINSTANCE.getRequirementConstraint();

		/**
		 * The meta object literal for the '{@link problemframework.impl.SubPFImpl <em>Sub PF</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see problemframework.impl.SubPFImpl
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getSubPF()
		 * @generated
		 */
		EClass SUB_PF = eINSTANCE.getSubPF();

		/**
		 * The meta object literal for the '{@link problemframework.attributeEnum <em>attribute Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see problemframework.attributeEnum
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getattributeEnum()
		 * @generated
		 */
		EEnum ATTRIBUTE_ENUM = eINSTANCE.getattributeEnum();

		/**
		 * The meta object literal for the '{@link problemframework.domainType <em>domain Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see problemframework.domainType
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getdomainType()
		 * @generated
		 */
		EEnum DOMAIN_TYPE = eINSTANCE.getdomainType();

		/**
		 * The meta object literal for the '<em>Attribute String</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getAttributeString()
		 * @generated
		 */
		EDataType ATTRIBUTE_STRING = eINSTANCE.getAttributeString();

		/**
		 * The meta object literal for the '<em>Lexical Type</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.Object
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getLexicalType()
		 * @generated
		 */
		EDataType LEXICAL_TYPE = eINSTANCE.getLexicalType();

		/**
		 * The meta object literal for the '<em>Machine Type</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see problemframework.impl.ProblemframeworkPackageImpl#getMachineType()
		 * @generated
		 */
		EDataType MACHINE_TYPE = eINSTANCE.getMachineType();

	}

} //ProblemframeworkPackage
