/**
 */
package problemframework.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import problemframework.Phenomenon;
import problemframework.ProblemframeworkPackage;
import problemframework.Requirement;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Requirement</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link problemframework.impl.RequirementImpl#getReferTo <em>Refer To</em>}</li>
 *   <li>{@link problemframework.impl.RequirementImpl#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.impl.RequirementImpl#isIsInteraction <em>Is Interaction</em>}</li>
 *   <li>{@link problemframework.impl.RequirementImpl#isIsService <em>Is Service</em>}</li>
 *   <li>{@link problemframework.impl.RequirementImpl#isIsUseCase <em>Is Use Case</em>}</li>
 *   <li>{@link problemframework.impl.RequirementImpl#isIsThirdPartServices <em>Is Third Part Services</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RequirementImpl extends MinimalEObjectImpl.Container implements Requirement {
	/**
	 * The cached value of the '{@link #getReferTo() <em>Refer To</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReferTo()
	 * @generated
	 * @ordered
	 */
	protected EList<Phenomenon> referTo;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsInteraction() <em>Is Interaction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsInteraction()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_INTERACTION_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsInteraction() <em>Is Interaction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsInteraction()
	 * @generated
	 * @ordered
	 */
	protected boolean isInteraction = IS_INTERACTION_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsService() <em>Is Service</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsService()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_SERVICE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsService() <em>Is Service</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsService()
	 * @generated
	 * @ordered
	 */
	protected boolean isService = IS_SERVICE_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsUseCase() <em>Is Use Case</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsUseCase()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_USE_CASE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsUseCase() <em>Is Use Case</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsUseCase()
	 * @generated
	 * @ordered
	 */
	protected boolean isUseCase = IS_USE_CASE_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsThirdPartServices() <em>Is Third Part Services</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsThirdPartServices()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_THIRD_PART_SERVICES_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsThirdPartServices() <em>Is Third Part Services</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsThirdPartServices()
	 * @generated
	 * @ordered
	 */
	protected boolean isThirdPartServices = IS_THIRD_PART_SERVICES_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RequirementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ProblemframeworkPackage.Literals.REQUIREMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Phenomenon> getReferTo() {
		if (referTo == null) {
			referTo = new EObjectResolvingEList<Phenomenon>(Phenomenon.class, this, ProblemframeworkPackage.REQUIREMENT__REFER_TO);
		}
		return referTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.REQUIREMENT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isIsInteraction() {
		return isInteraction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsInteraction(boolean newIsInteraction) {
		boolean oldIsInteraction = isInteraction;
		isInteraction = newIsInteraction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.REQUIREMENT__IS_INTERACTION, oldIsInteraction, isInteraction));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isIsService() {
		return isService;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsService(boolean newIsService) {
		boolean oldIsService = isService;
		isService = newIsService;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.REQUIREMENT__IS_SERVICE, oldIsService, isService));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isIsUseCase() {
		return isUseCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsUseCase(boolean newIsUseCase) {
		boolean oldIsUseCase = isUseCase;
		isUseCase = newIsUseCase;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.REQUIREMENT__IS_USE_CASE, oldIsUseCase, isUseCase));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isIsThirdPartServices() {
		return isThirdPartServices;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsThirdPartServices(boolean newIsThirdPartServices) {
		boolean oldIsThirdPartServices = isThirdPartServices;
		isThirdPartServices = newIsThirdPartServices;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.REQUIREMENT__IS_THIRD_PART_SERVICES, oldIsThirdPartServices, isThirdPartServices));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ProblemframeworkPackage.REQUIREMENT__REFER_TO:
				return getReferTo();
			case ProblemframeworkPackage.REQUIREMENT__NAME:
				return getName();
			case ProblemframeworkPackage.REQUIREMENT__IS_INTERACTION:
				return isIsInteraction();
			case ProblemframeworkPackage.REQUIREMENT__IS_SERVICE:
				return isIsService();
			case ProblemframeworkPackage.REQUIREMENT__IS_USE_CASE:
				return isIsUseCase();
			case ProblemframeworkPackage.REQUIREMENT__IS_THIRD_PART_SERVICES:
				return isIsThirdPartServices();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ProblemframeworkPackage.REQUIREMENT__REFER_TO:
				getReferTo().clear();
				getReferTo().addAll((Collection<? extends Phenomenon>)newValue);
				return;
			case ProblemframeworkPackage.REQUIREMENT__NAME:
				setName((String)newValue);
				return;
			case ProblemframeworkPackage.REQUIREMENT__IS_INTERACTION:
				setIsInteraction((Boolean)newValue);
				return;
			case ProblemframeworkPackage.REQUIREMENT__IS_SERVICE:
				setIsService((Boolean)newValue);
				return;
			case ProblemframeworkPackage.REQUIREMENT__IS_USE_CASE:
				setIsUseCase((Boolean)newValue);
				return;
			case ProblemframeworkPackage.REQUIREMENT__IS_THIRD_PART_SERVICES:
				setIsThirdPartServices((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ProblemframeworkPackage.REQUIREMENT__REFER_TO:
				getReferTo().clear();
				return;
			case ProblemframeworkPackage.REQUIREMENT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case ProblemframeworkPackage.REQUIREMENT__IS_INTERACTION:
				setIsInteraction(IS_INTERACTION_EDEFAULT);
				return;
			case ProblemframeworkPackage.REQUIREMENT__IS_SERVICE:
				setIsService(IS_SERVICE_EDEFAULT);
				return;
			case ProblemframeworkPackage.REQUIREMENT__IS_USE_CASE:
				setIsUseCase(IS_USE_CASE_EDEFAULT);
				return;
			case ProblemframeworkPackage.REQUIREMENT__IS_THIRD_PART_SERVICES:
				setIsThirdPartServices(IS_THIRD_PART_SERVICES_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ProblemframeworkPackage.REQUIREMENT__REFER_TO:
				return referTo != null && !referTo.isEmpty();
			case ProblemframeworkPackage.REQUIREMENT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case ProblemframeworkPackage.REQUIREMENT__IS_INTERACTION:
				return isInteraction != IS_INTERACTION_EDEFAULT;
			case ProblemframeworkPackage.REQUIREMENT__IS_SERVICE:
				return isService != IS_SERVICE_EDEFAULT;
			case ProblemframeworkPackage.REQUIREMENT__IS_USE_CASE:
				return isUseCase != IS_USE_CASE_EDEFAULT;
			case ProblemframeworkPackage.REQUIREMENT__IS_THIRD_PART_SERVICES:
				return isThirdPartServices != IS_THIRD_PART_SERVICES_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", isInteraction: ");
		result.append(isInteraction);
		result.append(", isService: ");
		result.append(isService);
		result.append(", isUseCase: ");
		result.append(isUseCase);
		result.append(", isThirdPartServices: ");
		result.append(isThirdPartServices);
		result.append(')');
		return result.toString();
	}

} //RequirementImpl
