/**
 */
package problemframework.impl;

import org.eclipse.emf.ecore.EClass;

import problemframework.ProblemframeworkPackage;
import problemframework.RequirementReference;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Requirement Reference</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RequirementReferenceImpl extends ReferenceImpl implements RequirementReference {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RequirementReferenceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ProblemframeworkPackage.Literals.REQUIREMENT_REFERENCE;
	}

} //RequirementReferenceImpl
