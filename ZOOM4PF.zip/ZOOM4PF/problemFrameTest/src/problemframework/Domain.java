/**
 */
package problemframework;

import BlockdDiagram.BDD;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

import stateMachine.StateMachine;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Domain</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link problemframework.Domain#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.Domain#getAddstate <em>Addstate</em>}</li>
 *   <li>{@link problemframework.Domain#getAddbdd <em>Addbdd</em>}</li>
 *   <li>{@link problemframework.Domain#isIsClass <em>Is Class</em>}</li>
 *   <li>{@link problemframework.Domain#isIsActor <em>Is Actor</em>}</li>
 *   <li>{@link problemframework.Domain#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see problemframework.ProblemframeworkPackage#getDomain()
 * @model
 * @generated
 */
public interface Domain extends EObject {
	/**
	 * Returns the value of the '<em><b>Is Class</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Class</em>' attribute.
	 * @see #setIsClass(boolean)
	 * @see problemframework.ProblemframeworkPackage#getDomain_IsClass()
	 * @model
	 * @generated
	 */
	boolean isIsClass();

	/**
	 * Sets the value of the '{@link problemframework.Domain#isIsClass <em>Is Class</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Class</em>' attribute.
	 * @see #isIsClass()
	 * @generated
	 */
	void setIsClass(boolean value);

	/**
	 * Returns the value of the '<em><b>Is Actor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Actor</em>' attribute.
	 * @see #setIsActor(boolean)
	 * @see problemframework.ProblemframeworkPackage#getDomain_IsActor()
	 * @model
	 * @generated
	 */
	boolean isIsActor();

	/**
	 * Sets the value of the '{@link problemframework.Domain#isIsActor <em>Is Actor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Actor</em>' attribute.
	 * @see #isIsActor()
	 * @generated
	 */
	void setIsActor(boolean value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link problemframework.domainType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see problemframework.domainType
	 * @see #setType(domainType)
	 * @see problemframework.ProblemframeworkPackage#getDomain_Type()
	 * @model
	 * @generated
	 */
	domainType getType();

	/**
	 * Sets the value of the '{@link problemframework.Domain#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see problemframework.domainType
	 * @see #getType()
	 * @generated
	 */
	void setType(domainType value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see problemframework.ProblemframeworkPackage#getDomain_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link problemframework.Domain#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Addstate</b></em>' reference list.
	 * The list contents are of type {@link stateMachine.StateMachine}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Addstate</em>' reference list.
	 * @see problemframework.ProblemframeworkPackage#getDomain_Addstate()
	 * @model
	 * @generated
	 */
	EList<StateMachine> getAddstate();

	/**
	 * Returns the value of the '<em><b>Addbdd</b></em>' reference list.
	 * The list contents are of type {@link BlockdDiagram.BDD}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Addbdd</em>' reference list.
	 * @see problemframework.ProblemframeworkPackage#getDomain_Addbdd()
	 * @model
	 * @generated
	 */
	EList<BDD> getAddbdd();

} // Domain
