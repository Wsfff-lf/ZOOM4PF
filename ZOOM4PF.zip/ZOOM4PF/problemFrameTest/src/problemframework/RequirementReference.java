/**
 */
package problemframework;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Requirement Reference</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see problemframework.ProblemframeworkPackage#getRequirementReference()
 * @model
 * @generated
 */
public interface RequirementReference extends Reference {
} // RequirementReference
