/**
 */
package BlockdDiagram;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Port Kind</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see BlockdDiagram.BlockdDiagramPackage#getPortKind()
 * @model
 * @generated
 */
public enum PortKind implements Enumerator {
	/**
	 * The '<em><b>Port</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PORT_VALUE
	 * @generated
	 * @ordered
	 */
	PORT(0, "port", "port"),

	/**
	 * The '<em><b>Up port</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UP_PORT_VALUE
	 * @generated
	 * @ordered
	 */
	UP_PORT(1, "up_port", "up_port"), /**
	 * The '<em><b>Down port</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DOWN_PORT_VALUE
	 * @generated
	 * @ordered
	 */
	DOWN_PORT(3, "down_port", "down_port"), /**
	 * The '<em><b>Left port</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LEFT_PORT_VALUE
	 * @generated
	 * @ordered
	 */
	LEFT_PORT(5, "left_port", "left_port"), /**
	 * The '<em><b>Right port</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RIGHT_PORT_VALUE
	 * @generated
	 * @ordered
	 */
	RIGHT_PORT(7, "right_port", "right_port"), /**
	 * The '<em><b>Verinandout</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #VERINANDOUT_VALUE
	 * @generated
	 * @ordered
	 */
	VERINANDOUT(9, "verinandout", "verinandout"), /**
	 * The '<em><b>Horinandout</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #HORINANDOUT_VALUE
	 * @generated
	 * @ordered
	 */
	HORINANDOUT(10, "horinandout", "horinandout");

	/**
	 * The '<em><b>Port</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PORT
	 * @model name="port"
	 * @generated
	 * @ordered
	 */
	public static final int PORT_VALUE = 0;

	/**
	 * The '<em><b>Up port</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UP_PORT
	 * @model name="up_port"
	 * @generated
	 * @ordered
	 */
	public static final int UP_PORT_VALUE = 1;

	/**
	 * The '<em><b>Down port</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DOWN_PORT
	 * @model name="down_port"
	 * @generated
	 * @ordered
	 */
	public static final int DOWN_PORT_VALUE = 3;

	/**
	 * The '<em><b>Left port</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LEFT_PORT
	 * @model name="left_port"
	 * @generated
	 * @ordered
	 */
	public static final int LEFT_PORT_VALUE = 5;

	/**
	 * The '<em><b>Right port</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RIGHT_PORT
	 * @model name="right_port"
	 * @generated
	 * @ordered
	 */
	public static final int RIGHT_PORT_VALUE = 7;

	/**
	 * The '<em><b>Verinandout</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #VERINANDOUT
	 * @model name="verinandout"
	 * @generated
	 * @ordered
	 */
	public static final int VERINANDOUT_VALUE = 9;

	/**
	 * The '<em><b>Horinandout</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #HORINANDOUT
	 * @model name="horinandout"
	 * @generated
	 * @ordered
	 */
	public static final int HORINANDOUT_VALUE = 10;

	/**
	 * An array of all the '<em><b>Port Kind</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final PortKind[] VALUES_ARRAY =
		new PortKind[] {
			PORT,
			UP_PORT,
			DOWN_PORT,
			LEFT_PORT,
			RIGHT_PORT,
			VERINANDOUT,
			HORINANDOUT,
		};

	/**
	 * A public read-only list of all the '<em><b>Port Kind</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<PortKind> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Port Kind</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static PortKind get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			PortKind result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Port Kind</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static PortKind getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			PortKind result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Port Kind</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static PortKind get(int value) {
		switch (value) {
			case PORT_VALUE: return PORT;
			case UP_PORT_VALUE: return UP_PORT;
			case DOWN_PORT_VALUE: return DOWN_PORT;
			case LEFT_PORT_VALUE: return LEFT_PORT;
			case RIGHT_PORT_VALUE: return RIGHT_PORT;
			case VERINANDOUT_VALUE: return VERINANDOUT;
			case HORINANDOUT_VALUE: return HORINANDOUT;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private PortKind(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //PortKind
