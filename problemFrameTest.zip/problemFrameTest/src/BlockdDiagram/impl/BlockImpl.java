/**
 */
package BlockdDiagram.impl;

import BlockdDiagram.Block;
import BlockdDiagram.BlockdDiagramPackage;
import BlockdDiagram.Connect;
import BlockdDiagram.ItemFlow;
import BlockdDiagram.Operations;
import BlockdDiagram.Part;
import BlockdDiagram.Port;
import BlockdDiagram.Propertys;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Block</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link BlockdDiagram.impl.BlockImpl#getOperations <em>Operations</em>}</li>
 *   <li>{@link BlockdDiagram.impl.BlockImpl#getPropertys <em>Propertys</em>}</li>
 *   <li>{@link BlockdDiagram.impl.BlockImpl#getName <em>Name</em>}</li>
 *   <li>{@link BlockdDiagram.impl.BlockImpl#getPart <em>Part</em>}</li>
 *   <li>{@link BlockdDiagram.impl.BlockImpl#getItemflow <em>Itemflow</em>}</li>
 *   <li>{@link BlockdDiagram.impl.BlockImpl#getPort <em>Port</em>}</li>
 *   <li>{@link BlockdDiagram.impl.BlockImpl#getConnect <em>Connect</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BlockImpl extends MinimalEObjectImpl.Container implements Block {
	/**
	 * The cached value of the '{@link #getOperations() <em>Operations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperations()
	 * @generated
	 * @ordered
	 */
	protected EList<Operations> operations;

	/**
	 * The cached value of the '{@link #getPropertys() <em>Propertys</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPropertys()
	 * @generated
	 * @ordered
	 */
	protected EList<Propertys> propertys;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPart() <em>Part</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPart()
	 * @generated
	 * @ordered
	 */
	protected EList<Part> part;

	/**
	 * The cached value of the '{@link #getItemflow() <em>Itemflow</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getItemflow()
	 * @generated
	 * @ordered
	 */
	protected EList<ItemFlow> itemflow;

	/**
	 * The cached value of the '{@link #getPort() <em>Port</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPort()
	 * @generated
	 * @ordered
	 */
	protected EList<Port> port;

	/**
	 * The cached value of the '{@link #getConnect() <em>Connect</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnect()
	 * @generated
	 * @ordered
	 */
	protected EList<Connect> connect;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BlockImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BlockdDiagramPackage.Literals.BLOCK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Operations> getOperations() {
		if (operations == null) {
			operations = new EObjectContainmentEList<Operations>(Operations.class, this, BlockdDiagramPackage.BLOCK__OPERATIONS);
		}
		return operations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Propertys> getPropertys() {
		if (propertys == null) {
			propertys = new EObjectContainmentEList<Propertys>(Propertys.class, this, BlockdDiagramPackage.BLOCK__PROPERTYS);
		}
		return propertys;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BlockdDiagramPackage.BLOCK__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Part> getPart() {
		if (part == null) {
			part = new EObjectContainmentEList<Part>(Part.class, this, BlockdDiagramPackage.BLOCK__PART);
		}
		return part;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<ItemFlow> getItemflow() {
		if (itemflow == null) {
			itemflow = new EObjectContainmentEList<ItemFlow>(ItemFlow.class, this, BlockdDiagramPackage.BLOCK__ITEMFLOW);
		}
		return itemflow;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Port> getPort() {
		if (port == null) {
			port = new EObjectContainmentEList<Port>(Port.class, this, BlockdDiagramPackage.BLOCK__PORT);
		}
		return port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Connect> getConnect() {
		if (connect == null) {
			connect = new EObjectContainmentEList<Connect>(Connect.class, this, BlockdDiagramPackage.BLOCK__CONNECT);
		}
		return connect;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case BlockdDiagramPackage.BLOCK__OPERATIONS:
				return ((InternalEList<?>)getOperations()).basicRemove(otherEnd, msgs);
			case BlockdDiagramPackage.BLOCK__PROPERTYS:
				return ((InternalEList<?>)getPropertys()).basicRemove(otherEnd, msgs);
			case BlockdDiagramPackage.BLOCK__PART:
				return ((InternalEList<?>)getPart()).basicRemove(otherEnd, msgs);
			case BlockdDiagramPackage.BLOCK__ITEMFLOW:
				return ((InternalEList<?>)getItemflow()).basicRemove(otherEnd, msgs);
			case BlockdDiagramPackage.BLOCK__PORT:
				return ((InternalEList<?>)getPort()).basicRemove(otherEnd, msgs);
			case BlockdDiagramPackage.BLOCK__CONNECT:
				return ((InternalEList<?>)getConnect()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case BlockdDiagramPackage.BLOCK__OPERATIONS:
				return getOperations();
			case BlockdDiagramPackage.BLOCK__PROPERTYS:
				return getPropertys();
			case BlockdDiagramPackage.BLOCK__NAME:
				return getName();
			case BlockdDiagramPackage.BLOCK__PART:
				return getPart();
			case BlockdDiagramPackage.BLOCK__ITEMFLOW:
				return getItemflow();
			case BlockdDiagramPackage.BLOCK__PORT:
				return getPort();
			case BlockdDiagramPackage.BLOCK__CONNECT:
				return getConnect();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case BlockdDiagramPackage.BLOCK__OPERATIONS:
				getOperations().clear();
				getOperations().addAll((Collection<? extends Operations>)newValue);
				return;
			case BlockdDiagramPackage.BLOCK__PROPERTYS:
				getPropertys().clear();
				getPropertys().addAll((Collection<? extends Propertys>)newValue);
				return;
			case BlockdDiagramPackage.BLOCK__NAME:
				setName((String)newValue);
				return;
			case BlockdDiagramPackage.BLOCK__PART:
				getPart().clear();
				getPart().addAll((Collection<? extends Part>)newValue);
				return;
			case BlockdDiagramPackage.BLOCK__ITEMFLOW:
				getItemflow().clear();
				getItemflow().addAll((Collection<? extends ItemFlow>)newValue);
				return;
			case BlockdDiagramPackage.BLOCK__PORT:
				getPort().clear();
				getPort().addAll((Collection<? extends Port>)newValue);
				return;
			case BlockdDiagramPackage.BLOCK__CONNECT:
				getConnect().clear();
				getConnect().addAll((Collection<? extends Connect>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case BlockdDiagramPackage.BLOCK__OPERATIONS:
				getOperations().clear();
				return;
			case BlockdDiagramPackage.BLOCK__PROPERTYS:
				getPropertys().clear();
				return;
			case BlockdDiagramPackage.BLOCK__NAME:
				setName(NAME_EDEFAULT);
				return;
			case BlockdDiagramPackage.BLOCK__PART:
				getPart().clear();
				return;
			case BlockdDiagramPackage.BLOCK__ITEMFLOW:
				getItemflow().clear();
				return;
			case BlockdDiagramPackage.BLOCK__PORT:
				getPort().clear();
				return;
			case BlockdDiagramPackage.BLOCK__CONNECT:
				getConnect().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case BlockdDiagramPackage.BLOCK__OPERATIONS:
				return operations != null && !operations.isEmpty();
			case BlockdDiagramPackage.BLOCK__PROPERTYS:
				return propertys != null && !propertys.isEmpty();
			case BlockdDiagramPackage.BLOCK__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case BlockdDiagramPackage.BLOCK__PART:
				return part != null && !part.isEmpty();
			case BlockdDiagramPackage.BLOCK__ITEMFLOW:
				return itemflow != null && !itemflow.isEmpty();
			case BlockdDiagramPackage.BLOCK__PORT:
				return port != null && !port.isEmpty();
			case BlockdDiagramPackage.BLOCK__CONNECT:
				return connect != null && !connect.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //BlockImpl
