/**
 */
package BlockdDiagram.impl;

import BlockdDiagram.BlockdDiagramPackage;
import BlockdDiagram.FlowKind;
import BlockdDiagram.ItemFlow;
import BlockdDiagram.Port;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Item Flow</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link BlockdDiagram.impl.ItemFlowImpl#getName <em>Name</em>}</li>
 *   <li>{@link BlockdDiagram.impl.ItemFlowImpl#getFlowKind <em>Flow Kind</em>}</li>
 *   <li>{@link BlockdDiagram.impl.ItemFlowImpl#getSource <em>Source</em>}</li>
 *   <li>{@link BlockdDiagram.impl.ItemFlowImpl#getTarget <em>Target</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ItemFlowImpl extends MinimalEObjectImpl.Container implements ItemFlow {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getFlowKind() <em>Flow Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFlowKind()
	 * @generated
	 * @ordered
	 */
	protected static final FlowKind FLOW_KIND_EDEFAULT = FlowKind.FLOW;

	/**
	 * The cached value of the '{@link #getFlowKind() <em>Flow Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFlowKind()
	 * @generated
	 * @ordered
	 */
	protected FlowKind flowKind = FLOW_KIND_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSource() <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource()
	 * @generated
	 * @ordered
	 */
	protected Port source;

	/**
	 * The cached value of the '{@link #getTarget() <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTarget()
	 * @generated
	 * @ordered
	 */
	protected Port target;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ItemFlowImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BlockdDiagramPackage.Literals.ITEM_FLOW;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BlockdDiagramPackage.ITEM_FLOW__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FlowKind getFlowKind() {
		return flowKind;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFlowKind(FlowKind newFlowKind) {
		FlowKind oldFlowKind = flowKind;
		flowKind = newFlowKind == null ? FLOW_KIND_EDEFAULT : newFlowKind;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BlockdDiagramPackage.ITEM_FLOW__FLOW_KIND, oldFlowKind, flowKind));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Port getSource() {
		if (source != null && source.eIsProxy()) {
			InternalEObject oldSource = (InternalEObject)source;
			source = (Port)eResolveProxy(oldSource);
			if (source != oldSource) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, BlockdDiagramPackage.ITEM_FLOW__SOURCE, oldSource, source));
			}
		}
		return source;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Port basicGetSource() {
		return source;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSource(Port newSource) {
		Port oldSource = source;
		source = newSource;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BlockdDiagramPackage.ITEM_FLOW__SOURCE, oldSource, source));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Port getTarget() {
		if (target != null && target.eIsProxy()) {
			InternalEObject oldTarget = (InternalEObject)target;
			target = (Port)eResolveProxy(oldTarget);
			if (target != oldTarget) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, BlockdDiagramPackage.ITEM_FLOW__TARGET, oldTarget, target));
			}
		}
		return target;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Port basicGetTarget() {
		return target;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTarget(Port newTarget) {
		Port oldTarget = target;
		target = newTarget;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BlockdDiagramPackage.ITEM_FLOW__TARGET, oldTarget, target));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case BlockdDiagramPackage.ITEM_FLOW__NAME:
				return getName();
			case BlockdDiagramPackage.ITEM_FLOW__FLOW_KIND:
				return getFlowKind();
			case BlockdDiagramPackage.ITEM_FLOW__SOURCE:
				if (resolve) return getSource();
				return basicGetSource();
			case BlockdDiagramPackage.ITEM_FLOW__TARGET:
				if (resolve) return getTarget();
				return basicGetTarget();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case BlockdDiagramPackage.ITEM_FLOW__NAME:
				setName((String)newValue);
				return;
			case BlockdDiagramPackage.ITEM_FLOW__FLOW_KIND:
				setFlowKind((FlowKind)newValue);
				return;
			case BlockdDiagramPackage.ITEM_FLOW__SOURCE:
				setSource((Port)newValue);
				return;
			case BlockdDiagramPackage.ITEM_FLOW__TARGET:
				setTarget((Port)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case BlockdDiagramPackage.ITEM_FLOW__NAME:
				setName(NAME_EDEFAULT);
				return;
			case BlockdDiagramPackage.ITEM_FLOW__FLOW_KIND:
				setFlowKind(FLOW_KIND_EDEFAULT);
				return;
			case BlockdDiagramPackage.ITEM_FLOW__SOURCE:
				setSource((Port)null);
				return;
			case BlockdDiagramPackage.ITEM_FLOW__TARGET:
				setTarget((Port)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case BlockdDiagramPackage.ITEM_FLOW__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case BlockdDiagramPackage.ITEM_FLOW__FLOW_KIND:
				return flowKind != FLOW_KIND_EDEFAULT;
			case BlockdDiagramPackage.ITEM_FLOW__SOURCE:
				return source != null;
			case BlockdDiagramPackage.ITEM_FLOW__TARGET:
				return target != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", flowKind: ");
		result.append(flowKind);
		result.append(')');
		return result.toString();
	}

} //ItemFlowImpl
