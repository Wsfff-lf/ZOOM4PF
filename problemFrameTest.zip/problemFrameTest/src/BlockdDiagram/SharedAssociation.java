/**
 */
package BlockdDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Shared Association</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link BlockdDiagram.SharedAssociation#getSource <em>Source</em>}</li>
 *   <li>{@link BlockdDiagram.SharedAssociation#getTarget <em>Target</em>}</li>
 *   <li>{@link BlockdDiagram.SharedAssociation#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see BlockdDiagram.BlockdDiagramPackage#getSharedAssociation()
 * @model
 * @generated
 */
public interface SharedAssociation extends EObject {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Block)
	 * @see BlockdDiagram.BlockdDiagramPackage#getSharedAssociation_Source()
	 * @model
	 * @generated
	 */
	Block getSource();

	/**
	 * Sets the value of the '{@link BlockdDiagram.SharedAssociation#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Block value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(Block)
	 * @see BlockdDiagram.BlockdDiagramPackage#getSharedAssociation_Target()
	 * @model
	 * @generated
	 */
	Block getTarget();

	/**
	 * Sets the value of the '{@link BlockdDiagram.SharedAssociation#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(Block value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see BlockdDiagram.BlockdDiagramPackage#getSharedAssociation_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link BlockdDiagram.SharedAssociation#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // SharedAssociation
