/**
 */
package BlockdDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Item Flow</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link BlockdDiagram.ItemFlow#getName <em>Name</em>}</li>
 *   <li>{@link BlockdDiagram.ItemFlow#getFlowKind <em>Flow Kind</em>}</li>
 *   <li>{@link BlockdDiagram.ItemFlow#getSource <em>Source</em>}</li>
 *   <li>{@link BlockdDiagram.ItemFlow#getTarget <em>Target</em>}</li>
 * </ul>
 *
 * @see BlockdDiagram.BlockdDiagramPackage#getItemFlow()
 * @model
 * @generated
 */
public interface ItemFlow extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see BlockdDiagram.BlockdDiagramPackage#getItemFlow_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link BlockdDiagram.ItemFlow#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Flow Kind</b></em>' attribute.
	 * The literals are from the enumeration {@link BlockdDiagram.FlowKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Flow Kind</em>' attribute.
	 * @see BlockdDiagram.FlowKind
	 * @see #setFlowKind(FlowKind)
	 * @see BlockdDiagram.BlockdDiagramPackage#getItemFlow_FlowKind()
	 * @model
	 * @generated
	 */
	FlowKind getFlowKind();

	/**
	 * Sets the value of the '{@link BlockdDiagram.ItemFlow#getFlowKind <em>Flow Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Flow Kind</em>' attribute.
	 * @see BlockdDiagram.FlowKind
	 * @see #getFlowKind()
	 * @generated
	 */
	void setFlowKind(FlowKind value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Port)
	 * @see BlockdDiagram.BlockdDiagramPackage#getItemFlow_Source()
	 * @model
	 * @generated
	 */
	Port getSource();

	/**
	 * Sets the value of the '{@link BlockdDiagram.ItemFlow#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Port value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(Port)
	 * @see BlockdDiagram.BlockdDiagramPackage#getItemFlow_Target()
	 * @model
	 * @generated
	 */
	Port getTarget();

	/**
	 * Sets the value of the '{@link BlockdDiagram.ItemFlow#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(Port value);

} // ItemFlow
