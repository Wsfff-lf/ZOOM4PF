/**
 */
package BlockdDiagram;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>BDD</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link BlockdDiagram.BDD#getBlock <em>Block</em>}</li>
 *   <li>{@link BlockdDiagram.BDD#getShared <em>Shared</em>}</li>
 *   <li>{@link BlockdDiagram.BDD#getGeneral <em>General</em>}</li>
 *   <li>{@link BlockdDiagram.BDD#getDependency <em>Dependency</em>}</li>
 *   <li>{@link BlockdDiagram.BDD#getPartass <em>Partass</em>}</li>
 *   <li>{@link BlockdDiagram.BDD#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see BlockdDiagram.BlockdDiagramPackage#getBDD()
 * @model
 * @generated
 */
public interface BDD extends EObject {
	/**
	 * Returns the value of the '<em><b>Block</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.Block}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Block</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getBDD_Block()
	 * @model containment="true"
	 * @generated
	 */
	EList<Block> getBlock();

	/**
	 * Returns the value of the '<em><b>Shared</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.SharedAssociation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Shared</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getBDD_Shared()
	 * @model containment="true"
	 * @generated
	 */
	EList<SharedAssociation> getShared();

	/**
	 * Returns the value of the '<em><b>General</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.Generalization}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>General</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getBDD_General()
	 * @model containment="true"
	 * @generated
	 */
	EList<Generalization> getGeneral();

	/**
	 * Returns the value of the '<em><b>Dependency</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.Dependency}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dependency</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getBDD_Dependency()
	 * @model containment="true"
	 * @generated
	 */
	EList<Dependency> getDependency();

	/**
	 * Returns the value of the '<em><b>Partass</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.PartAssociation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Partass</em>' containment reference list.
	 * @see BlockdDiagram.BlockdDiagramPackage#getBDD_Partass()
	 * @model containment="true"
	 * @generated
	 */
	EList<PartAssociation> getPartass();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see BlockdDiagram.BlockdDiagramPackage#getBDD_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link BlockdDiagram.BDD#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // BDD
