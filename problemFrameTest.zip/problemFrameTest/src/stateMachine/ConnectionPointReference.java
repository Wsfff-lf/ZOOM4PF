/**
 */
package stateMachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connection Point Reference</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link stateMachine.ConnectionPointReference#getExit <em>Exit</em>}</li>
 *   <li>{@link stateMachine.ConnectionPointReference#getEntry <em>Entry</em>}</li>
 *   <li>{@link stateMachine.ConnectionPointReference#getState <em>State</em>}</li>
 * </ul>
 *
 * @see stateMachine.StateMachinePackage#getConnectionPointReference()
 * @model
 * @generated
 */
public interface ConnectionPointReference extends Vertex {
	/**
	 * Returns the value of the '<em><b>Exit</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exit</em>' reference.
	 * @see #setExit(Pseudostate)
	 * @see stateMachine.StateMachinePackage#getConnectionPointReference_Exit()
	 * @model
	 * @generated
	 */
	Pseudostate getExit();

	/**
	 * Sets the value of the '{@link stateMachine.ConnectionPointReference#getExit <em>Exit</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Exit</em>' reference.
	 * @see #getExit()
	 * @generated
	 */
	void setExit(Pseudostate value);

	/**
	 * Returns the value of the '<em><b>Entry</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entry</em>' reference.
	 * @see #setEntry(Pseudostate)
	 * @see stateMachine.StateMachinePackage#getConnectionPointReference_Entry()
	 * @model
	 * @generated
	 */
	Pseudostate getEntry();

	/**
	 * Sets the value of the '{@link stateMachine.ConnectionPointReference#getEntry <em>Entry</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Entry</em>' reference.
	 * @see #getEntry()
	 * @generated
	 */
	void setEntry(Pseudostate value);

	/**
	 * Returns the value of the '<em><b>State</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link stateMachine.State#getConnection <em>Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' container reference.
	 * @see #setState(State)
	 * @see stateMachine.StateMachinePackage#getConnectionPointReference_State()
	 * @see stateMachine.State#getConnection
	 * @model opposite="connection" transient="false"
	 * @generated
	 */
	State getState();

	/**
	 * Sets the value of the '{@link stateMachine.ConnectionPointReference#getState <em>State</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State</em>' container reference.
	 * @see #getState()
	 * @generated
	 */
	void setState(State value);

} // ConnectionPointReference
