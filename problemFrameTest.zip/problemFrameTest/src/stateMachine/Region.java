/**
 */
package stateMachine;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Region</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link stateMachine.Region#getState <em>State</em>}</li>
 *   <li>{@link stateMachine.Region#getStatemachine <em>Statemachine</em>}</li>
 *   <li>{@link stateMachine.Region#getTransition <em>Transition</em>}</li>
 *   <li>{@link stateMachine.Region#getSubvertex <em>Subvertex</em>}</li>
 * </ul>
 *
 * @see stateMachine.StateMachinePackage#getRegion()
 * @model
 * @generated
 */
public interface Region extends Namespace {
	/**
	 * Returns the value of the '<em><b>State</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link stateMachine.State#getRegion <em>Region</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' container reference.
	 * @see #setState(State)
	 * @see stateMachine.StateMachinePackage#getRegion_State()
	 * @see stateMachine.State#getRegion
	 * @model opposite="region" transient="false"
	 * @generated
	 */
	State getState();

	/**
	 * Sets the value of the '{@link stateMachine.Region#getState <em>State</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State</em>' container reference.
	 * @see #getState()
	 * @generated
	 */
	void setState(State value);

	/**
	 * Returns the value of the '<em><b>Statemachine</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link stateMachine.StateMachine#getRegion <em>Region</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Statemachine</em>' container reference.
	 * @see #setStatemachine(StateMachine)
	 * @see stateMachine.StateMachinePackage#getRegion_Statemachine()
	 * @see stateMachine.StateMachine#getRegion
	 * @model opposite="region" transient="false"
	 * @generated
	 */
	StateMachine getStatemachine();

	/**
	 * Sets the value of the '{@link stateMachine.Region#getStatemachine <em>Statemachine</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Statemachine</em>' container reference.
	 * @see #getStatemachine()
	 * @generated
	 */
	void setStatemachine(StateMachine value);

	/**
	 * Returns the value of the '<em><b>Transition</b></em>' containment reference list.
	 * The list contents are of type {@link stateMachine.Transition}.
	 * It is bidirectional and its opposite is '{@link stateMachine.Transition#getContainer <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transition</em>' containment reference list.
	 * @see stateMachine.StateMachinePackage#getRegion_Transition()
	 * @see stateMachine.Transition#getContainer
	 * @model opposite="container" containment="true"
	 * @generated
	 */
	EList<Transition> getTransition();

	/**
	 * Returns the value of the '<em><b>Subvertex</b></em>' containment reference list.
	 * The list contents are of type {@link stateMachine.Vertex}.
	 * It is bidirectional and its opposite is '{@link stateMachine.Vertex#getContainer <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subvertex</em>' containment reference list.
	 * @see stateMachine.StateMachinePackage#getRegion_Subvertex()
	 * @see stateMachine.Vertex#getContainer
	 * @model opposite="container" containment="true"
	 * @generated
	 */
	EList<Vertex> getSubvertex();

} // Region
