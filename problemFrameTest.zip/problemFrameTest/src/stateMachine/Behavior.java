/**
 */
package stateMachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see stateMachine.StateMachinePackage#getBehavior()
 * @model abstract="true"
 * @generated
 */
public interface Behavior extends Namespace {
} // Behavior
