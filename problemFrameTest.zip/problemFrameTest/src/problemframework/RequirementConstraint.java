/**
 */
package problemframework;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Requirement Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see problemframework.ProblemframeworkPackage#getRequirementConstraint()
 * @model
 * @generated
 */
public interface RequirementConstraint extends Reference {
} // RequirementConstraint
