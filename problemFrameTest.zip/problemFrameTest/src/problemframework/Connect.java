/**
 */
package problemframework;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connect</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link problemframework.Connect#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.Connect#getSource <em>Source</em>}</li>
 *   <li>{@link problemframework.Connect#getTarget <em>Target</em>}</li>
 * </ul>
 *
 * @see problemframework.ProblemframeworkPackage#getConnect()
 * @model
 * @generated
 */
public interface Connect extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see problemframework.ProblemframeworkPackage#getConnect_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link problemframework.Connect#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Part)
	 * @see problemframework.ProblemframeworkPackage#getConnect_Source()
	 * @model
	 * @generated
	 */
	Part getSource();

	/**
	 * Sets the value of the '{@link problemframework.Connect#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Part value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(Part)
	 * @see problemframework.ProblemframeworkPackage#getConnect_Target()
	 * @model
	 * @generated
	 */
	Part getTarget();

	/**
	 * Sets the value of the '{@link problemframework.Connect#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(Part value);

} // Connect
