/**
 */
package problemframework;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Part</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link problemframework.Part#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.Part#getPartKind <em>Part Kind</em>}</li>
 *   <li>{@link problemframework.Part#getPart2port <em>Part2port</em>}</li>
 * </ul>
 *
 * @see problemframework.ProblemframeworkPackage#getPart()
 * @model
 * @generated
 */
public interface Part extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see problemframework.ProblemframeworkPackage#getPart_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link problemframework.Part#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Part Kind</b></em>' attribute.
	 * The literals are from the enumeration {@link problemframework.PartKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Part Kind</em>' attribute.
	 * @see problemframework.PartKind
	 * @see #setPartKind(PartKind)
	 * @see problemframework.ProblemframeworkPackage#getPart_PartKind()
	 * @model
	 * @generated
	 */
	PartKind getPartKind();

	/**
	 * Sets the value of the '{@link problemframework.Part#getPartKind <em>Part Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Part Kind</em>' attribute.
	 * @see problemframework.PartKind
	 * @see #getPartKind()
	 * @generated
	 */
	void setPartKind(PartKind value);

	/**
	 * Returns the value of the '<em><b>Part2port</b></em>' containment reference list.
	 * The list contents are of type {@link problemframework.Port}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Part2port</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getPart_Part2port()
	 * @model containment="true"
	 * @generated
	 */
	EList<Port> getPart2port();

} // Part
