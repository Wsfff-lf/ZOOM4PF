/**
 */
package problemframework.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import problemframework.Domain;
import problemframework.Machine;
import problemframework.Phenomenon;
import problemframework.ProblemframeworkPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Phenomenon</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link problemframework.impl.PhenomenonImpl#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.impl.PhenomenonImpl#isIsShared <em>Is Shared</em>}</li>
 *   <li>{@link problemframework.impl.PhenomenonImpl#getBelongTo <em>Belong To</em>}</li>
 *   <li>{@link problemframework.impl.PhenomenonImpl#getObservedBy <em>Observed By</em>}</li>
 *   <li>{@link problemframework.impl.PhenomenonImpl#getTargettodomain <em>Targettodomain</em>}</li>
 *   <li>{@link problemframework.impl.PhenomenonImpl#getSourcefromdomain <em>Sourcefromdomain</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PhenomenonImpl extends MinimalEObjectImpl.Container implements Phenomenon {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsShared() <em>Is Shared</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsShared()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_SHARED_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsShared() <em>Is Shared</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsShared()
	 * @generated
	 * @ordered
	 */
	protected boolean isShared = IS_SHARED_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBelongTo() <em>Belong To</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBelongTo()
	 * @generated
	 * @ordered
	 */
	protected EList<Domain> belongTo;

	/**
	 * The cached value of the '{@link #getObservedBy() <em>Observed By</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObservedBy()
	 * @generated
	 * @ordered
	 */
	protected Machine observedBy;

	/**
	 * The cached value of the '{@link #getTargettodomain() <em>Targettodomain</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTargettodomain()
	 * @generated
	 * @ordered
	 */
	protected Domain targettodomain;

	/**
	 * The cached value of the '{@link #getSourcefromdomain() <em>Sourcefromdomain</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourcefromdomain()
	 * @generated
	 * @ordered
	 */
	protected Domain sourcefromdomain;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PhenomenonImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ProblemframeworkPackage.Literals.PHENOMENON;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.PHENOMENON__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isIsShared() {
		return isShared;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsShared(boolean newIsShared) {
		boolean oldIsShared = isShared;
		isShared = newIsShared;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.PHENOMENON__IS_SHARED, oldIsShared, isShared));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Domain> getBelongTo() {
		if (belongTo == null) {
			belongTo = new EObjectResolvingEList<Domain>(Domain.class, this, ProblemframeworkPackage.PHENOMENON__BELONG_TO);
		}
		return belongTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Machine getObservedBy() {
		if (observedBy != null && observedBy.eIsProxy()) {
			InternalEObject oldObservedBy = (InternalEObject)observedBy;
			observedBy = (Machine)eResolveProxy(oldObservedBy);
			if (observedBy != oldObservedBy) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ProblemframeworkPackage.PHENOMENON__OBSERVED_BY, oldObservedBy, observedBy));
			}
		}
		return observedBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Machine basicGetObservedBy() {
		return observedBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setObservedBy(Machine newObservedBy) {
		Machine oldObservedBy = observedBy;
		observedBy = newObservedBy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.PHENOMENON__OBSERVED_BY, oldObservedBy, observedBy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Domain getTargettodomain() {
		if (targettodomain != null && targettodomain.eIsProxy()) {
			InternalEObject oldTargettodomain = (InternalEObject)targettodomain;
			targettodomain = (Domain)eResolveProxy(oldTargettodomain);
			if (targettodomain != oldTargettodomain) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ProblemframeworkPackage.PHENOMENON__TARGETTODOMAIN, oldTargettodomain, targettodomain));
			}
		}
		return targettodomain;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Domain basicGetTargettodomain() {
		return targettodomain;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTargettodomain(Domain newTargettodomain) {
		Domain oldTargettodomain = targettodomain;
		targettodomain = newTargettodomain;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.PHENOMENON__TARGETTODOMAIN, oldTargettodomain, targettodomain));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Domain getSourcefromdomain() {
		if (sourcefromdomain != null && sourcefromdomain.eIsProxy()) {
			InternalEObject oldSourcefromdomain = (InternalEObject)sourcefromdomain;
			sourcefromdomain = (Domain)eResolveProxy(oldSourcefromdomain);
			if (sourcefromdomain != oldSourcefromdomain) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ProblemframeworkPackage.PHENOMENON__SOURCEFROMDOMAIN, oldSourcefromdomain, sourcefromdomain));
			}
		}
		return sourcefromdomain;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Domain basicGetSourcefromdomain() {
		return sourcefromdomain;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSourcefromdomain(Domain newSourcefromdomain) {
		Domain oldSourcefromdomain = sourcefromdomain;
		sourcefromdomain = newSourcefromdomain;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.PHENOMENON__SOURCEFROMDOMAIN, oldSourcefromdomain, sourcefromdomain));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ProblemframeworkPackage.PHENOMENON__NAME:
				return getName();
			case ProblemframeworkPackage.PHENOMENON__IS_SHARED:
				return isIsShared();
			case ProblemframeworkPackage.PHENOMENON__BELONG_TO:
				return getBelongTo();
			case ProblemframeworkPackage.PHENOMENON__OBSERVED_BY:
				if (resolve) return getObservedBy();
				return basicGetObservedBy();
			case ProblemframeworkPackage.PHENOMENON__TARGETTODOMAIN:
				if (resolve) return getTargettodomain();
				return basicGetTargettodomain();
			case ProblemframeworkPackage.PHENOMENON__SOURCEFROMDOMAIN:
				if (resolve) return getSourcefromdomain();
				return basicGetSourcefromdomain();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ProblemframeworkPackage.PHENOMENON__NAME:
				setName((String)newValue);
				return;
			case ProblemframeworkPackage.PHENOMENON__IS_SHARED:
				setIsShared((Boolean)newValue);
				return;
			case ProblemframeworkPackage.PHENOMENON__BELONG_TO:
				getBelongTo().clear();
				getBelongTo().addAll((Collection<? extends Domain>)newValue);
				return;
			case ProblemframeworkPackage.PHENOMENON__OBSERVED_BY:
				setObservedBy((Machine)newValue);
				return;
			case ProblemframeworkPackage.PHENOMENON__TARGETTODOMAIN:
				setTargettodomain((Domain)newValue);
				return;
			case ProblemframeworkPackage.PHENOMENON__SOURCEFROMDOMAIN:
				setSourcefromdomain((Domain)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ProblemframeworkPackage.PHENOMENON__NAME:
				setName(NAME_EDEFAULT);
				return;
			case ProblemframeworkPackage.PHENOMENON__IS_SHARED:
				setIsShared(IS_SHARED_EDEFAULT);
				return;
			case ProblemframeworkPackage.PHENOMENON__BELONG_TO:
				getBelongTo().clear();
				return;
			case ProblemframeworkPackage.PHENOMENON__OBSERVED_BY:
				setObservedBy((Machine)null);
				return;
			case ProblemframeworkPackage.PHENOMENON__TARGETTODOMAIN:
				setTargettodomain((Domain)null);
				return;
			case ProblemframeworkPackage.PHENOMENON__SOURCEFROMDOMAIN:
				setSourcefromdomain((Domain)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ProblemframeworkPackage.PHENOMENON__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case ProblemframeworkPackage.PHENOMENON__IS_SHARED:
				return isShared != IS_SHARED_EDEFAULT;
			case ProblemframeworkPackage.PHENOMENON__BELONG_TO:
				return belongTo != null && !belongTo.isEmpty();
			case ProblemframeworkPackage.PHENOMENON__OBSERVED_BY:
				return observedBy != null;
			case ProblemframeworkPackage.PHENOMENON__TARGETTODOMAIN:
				return targettodomain != null;
			case ProblemframeworkPackage.PHENOMENON__SOURCEFROMDOMAIN:
				return sourcefromdomain != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", isShared: ");
		result.append(isShared);
		result.append(')');
		return result.toString();
	}

} //PhenomenonImpl
