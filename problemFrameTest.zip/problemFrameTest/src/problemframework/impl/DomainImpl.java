/**
 */
package problemframework.impl;

import BlockdDiagram.BDD;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import problemframework.Domain;
import problemframework.ProblemframeworkPackage;
import problemframework.domainType;

import stateMachine.StateMachine;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Domain</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link problemframework.impl.DomainImpl#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.impl.DomainImpl#getAddstate <em>Addstate</em>}</li>
 *   <li>{@link problemframework.impl.DomainImpl#getAddbdd <em>Addbdd</em>}</li>
 *   <li>{@link problemframework.impl.DomainImpl#isIsClass <em>Is Class</em>}</li>
 *   <li>{@link problemframework.impl.DomainImpl#isIsActor <em>Is Actor</em>}</li>
 *   <li>{@link problemframework.impl.DomainImpl#getType <em>Type</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DomainImpl extends MinimalEObjectImpl.Container implements Domain {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAddstate() <em>Addstate</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAddstate()
	 * @generated
	 * @ordered
	 */
	protected EList<StateMachine> addstate;

	/**
	 * The cached value of the '{@link #getAddbdd() <em>Addbdd</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAddbdd()
	 * @generated
	 * @ordered
	 */
	protected EList<BDD> addbdd;

	/**
	 * The default value of the '{@link #isIsClass() <em>Is Class</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsClass()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_CLASS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsClass() <em>Is Class</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsClass()
	 * @generated
	 * @ordered
	 */
	protected boolean isClass = IS_CLASS_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsActor() <em>Is Actor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsActor()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_ACTOR_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsActor() <em>Is Actor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsActor()
	 * @generated
	 * @ordered
	 */
	protected boolean isActor = IS_ACTOR_EDEFAULT;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final domainType TYPE_EDEFAULT = domainType.BIDDABLE_TYPE;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected domainType type = TYPE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DomainImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ProblemframeworkPackage.Literals.DOMAIN;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.DOMAIN__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<StateMachine> getAddstate() {
		if (addstate == null) {
			addstate = new EObjectResolvingEList<StateMachine>(StateMachine.class, this, ProblemframeworkPackage.DOMAIN__ADDSTATE);
		}
		return addstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<BDD> getAddbdd() {
		if (addbdd == null) {
			addbdd = new EObjectResolvingEList<BDD>(BDD.class, this, ProblemframeworkPackage.DOMAIN__ADDBDD);
		}
		return addbdd;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isIsClass() {
		return isClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsClass(boolean newIsClass) {
		boolean oldIsClass = isClass;
		isClass = newIsClass;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.DOMAIN__IS_CLASS, oldIsClass, isClass));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isIsActor() {
		return isActor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsActor(boolean newIsActor) {
		boolean oldIsActor = isActor;
		isActor = newIsActor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.DOMAIN__IS_ACTOR, oldIsActor, isActor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public domainType getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setType(domainType newType) {
		domainType oldType = type;
		type = newType == null ? TYPE_EDEFAULT : newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.DOMAIN__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ProblemframeworkPackage.DOMAIN__NAME:
				return getName();
			case ProblemframeworkPackage.DOMAIN__ADDSTATE:
				return getAddstate();
			case ProblemframeworkPackage.DOMAIN__ADDBDD:
				return getAddbdd();
			case ProblemframeworkPackage.DOMAIN__IS_CLASS:
				return isIsClass();
			case ProblemframeworkPackage.DOMAIN__IS_ACTOR:
				return isIsActor();
			case ProblemframeworkPackage.DOMAIN__TYPE:
				return getType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ProblemframeworkPackage.DOMAIN__NAME:
				setName((String)newValue);
				return;
			case ProblemframeworkPackage.DOMAIN__ADDSTATE:
				getAddstate().clear();
				getAddstate().addAll((Collection<? extends StateMachine>)newValue);
				return;
			case ProblemframeworkPackage.DOMAIN__ADDBDD:
				getAddbdd().clear();
				getAddbdd().addAll((Collection<? extends BDD>)newValue);
				return;
			case ProblemframeworkPackage.DOMAIN__IS_CLASS:
				setIsClass((Boolean)newValue);
				return;
			case ProblemframeworkPackage.DOMAIN__IS_ACTOR:
				setIsActor((Boolean)newValue);
				return;
			case ProblemframeworkPackage.DOMAIN__TYPE:
				setType((domainType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ProblemframeworkPackage.DOMAIN__NAME:
				setName(NAME_EDEFAULT);
				return;
			case ProblemframeworkPackage.DOMAIN__ADDSTATE:
				getAddstate().clear();
				return;
			case ProblemframeworkPackage.DOMAIN__ADDBDD:
				getAddbdd().clear();
				return;
			case ProblemframeworkPackage.DOMAIN__IS_CLASS:
				setIsClass(IS_CLASS_EDEFAULT);
				return;
			case ProblemframeworkPackage.DOMAIN__IS_ACTOR:
				setIsActor(IS_ACTOR_EDEFAULT);
				return;
			case ProblemframeworkPackage.DOMAIN__TYPE:
				setType(TYPE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ProblemframeworkPackage.DOMAIN__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case ProblemframeworkPackage.DOMAIN__ADDSTATE:
				return addstate != null && !addstate.isEmpty();
			case ProblemframeworkPackage.DOMAIN__ADDBDD:
				return addbdd != null && !addbdd.isEmpty();
			case ProblemframeworkPackage.DOMAIN__IS_CLASS:
				return isClass != IS_CLASS_EDEFAULT;
			case ProblemframeworkPackage.DOMAIN__IS_ACTOR:
				return isActor != IS_ACTOR_EDEFAULT;
			case ProblemframeworkPackage.DOMAIN__TYPE:
				return type != TYPE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", isClass: ");
		result.append(isClass);
		result.append(", isActor: ");
		result.append(isActor);
		result.append(", type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //DomainImpl
