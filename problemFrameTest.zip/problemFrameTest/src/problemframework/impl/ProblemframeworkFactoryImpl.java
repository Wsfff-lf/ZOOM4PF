/**
 */
package problemframework.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import problemframework.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ProblemframeworkFactoryImpl extends EFactoryImpl implements ProblemframeworkFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ProblemframeworkFactory init() {
		try {
			ProblemframeworkFactory theProblemframeworkFactory = (ProblemframeworkFactory)EPackage.Registry.INSTANCE.getEFactory(ProblemframeworkPackage.eNS_URI);
			if (theProblemframeworkFactory != null) {
				return theProblemframeworkFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ProblemframeworkFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProblemframeworkFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK: return createProblemFramework();
			case ProblemframeworkPackage.MACHINE: return createMachine();
			case ProblemframeworkPackage.DOMAIN: return createDomain();
			case ProblemframeworkPackage.PHENOMENON: return createPhenomenon();
			case ProblemframeworkPackage.REQUIREMENT: return createRequirement();
			case ProblemframeworkPackage.REQUIREMENT_REFERENCE: return createRequirementReference();
			case ProblemframeworkPackage.REQUIREMENT_CONSTRAINT: return createRequirementConstraint();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case ProblemframeworkPackage.ATTRIBUTE_ENUM:
				return createattributeEnumFromString(eDataType, initialValue);
			case ProblemframeworkPackage.DOMAIN_TYPE:
				return createdomainTypeFromString(eDataType, initialValue);
			case ProblemframeworkPackage.ATTRIBUTE_STRING:
				return createAttributeStringFromString(eDataType, initialValue);
			case ProblemframeworkPackage.LEXICAL_TYPE:
				return createLexicalTypeFromString(eDataType, initialValue);
			case ProblemframeworkPackage.MACHINE_TYPE:
				return createMachineTypeFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case ProblemframeworkPackage.ATTRIBUTE_ENUM:
				return convertattributeEnumToString(eDataType, instanceValue);
			case ProblemframeworkPackage.DOMAIN_TYPE:
				return convertdomainTypeToString(eDataType, instanceValue);
			case ProblemframeworkPackage.ATTRIBUTE_STRING:
				return convertAttributeStringToString(eDataType, instanceValue);
			case ProblemframeworkPackage.LEXICAL_TYPE:
				return convertLexicalTypeToString(eDataType, instanceValue);
			case ProblemframeworkPackage.MACHINE_TYPE:
				return convertMachineTypeToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ProblemFramework createProblemFramework() {
		ProblemFrameworkImpl problemFramework = new ProblemFrameworkImpl();
		return problemFramework;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Machine createMachine() {
		MachineImpl machine = new MachineImpl();
		return machine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Domain createDomain() {
		DomainImpl domain = new DomainImpl();
		return domain;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Phenomenon createPhenomenon() {
		PhenomenonImpl phenomenon = new PhenomenonImpl();
		return phenomenon;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Requirement createRequirement() {
		RequirementImpl requirement = new RequirementImpl();
		return requirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RequirementReference createRequirementReference() {
		RequirementReferenceImpl requirementReference = new RequirementReferenceImpl();
		return requirementReference;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RequirementConstraint createRequirementConstraint() {
		RequirementConstraintImpl requirementConstraint = new RequirementConstraintImpl();
		return requirementConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public attributeEnum createattributeEnumFromString(EDataType eDataType, String initialValue) {
		attributeEnum result = attributeEnum.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertattributeEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public domainType createdomainTypeFromString(EDataType eDataType, String initialValue) {
		domainType result = domainType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertdomainTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createAttributeStringFromString(EDataType eDataType, String initialValue) {
		return (String)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertAttributeStringToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object createLexicalTypeFromString(EDataType eDataType, String initialValue) {
		return super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLexicalTypeToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createMachineTypeFromString(EDataType eDataType, String initialValue) {
		return (String)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertMachineTypeToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ProblemframeworkPackage getProblemframeworkPackage() {
		return (ProblemframeworkPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ProblemframeworkPackage getPackage() {
		return ProblemframeworkPackage.eINSTANCE;
	}

} //ProblemframeworkFactoryImpl
