/**
 */
package problemframework.impl;

import org.eclipse.emf.ecore.EClass;

import problemframework.ProblemframeworkPackage;
import problemframework.RequirementConstraint;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Requirement Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RequirementConstraintImpl extends ReferenceImpl implements RequirementConstraint {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RequirementConstraintImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ProblemframeworkPackage.Literals.REQUIREMENT_CONSTRAINT;
	}

} //RequirementConstraintImpl
