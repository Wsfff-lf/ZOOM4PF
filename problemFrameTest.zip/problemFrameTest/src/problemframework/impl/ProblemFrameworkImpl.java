/**
 */
package problemframework.impl;

import BlockdDiagram.BDD;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import problemframework.Domain;
import problemframework.Machine;
import problemframework.Phenomenon;
import problemframework.ProblemFramework;
import problemframework.ProblemframeworkPackage;
import problemframework.Reference;
import problemframework.Requirement;

import stateMachine.StateMachine;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Problem Framework</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link problemframework.impl.ProblemFrameworkImpl#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.impl.ProblemFrameworkImpl#getDomain <em>Domain</em>}</li>
 *   <li>{@link problemframework.impl.ProblemFrameworkImpl#getMachine <em>Machine</em>}</li>
 *   <li>{@link problemframework.impl.ProblemFrameworkImpl#getPhenomenon <em>Phenomenon</em>}</li>
 *   <li>{@link problemframework.impl.ProblemFrameworkImpl#getRequirement <em>Requirement</em>}</li>
 *   <li>{@link problemframework.impl.ProblemFrameworkImpl#getReference <em>Reference</em>}</li>
 *   <li>{@link problemframework.impl.ProblemFrameworkImpl#getExstate <em>Exstate</em>}</li>
 *   <li>{@link problemframework.impl.ProblemFrameworkImpl#getExbdd <em>Exbdd</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ProblemFrameworkImpl extends SubPFImpl implements ProblemFramework {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDomain() <em>Domain</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDomain()
	 * @generated
	 * @ordered
	 */
	protected EList<Domain> domain;

	/**
	 * The cached value of the '{@link #getMachine() <em>Machine</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMachine()
	 * @generated
	 * @ordered
	 */
	protected EList<Machine> machine;

	/**
	 * The cached value of the '{@link #getPhenomenon() <em>Phenomenon</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhenomenon()
	 * @generated
	 * @ordered
	 */
	protected EList<Phenomenon> phenomenon;

	/**
	 * The cached value of the '{@link #getRequirement() <em>Requirement</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRequirement()
	 * @generated
	 * @ordered
	 */
	protected EList<Requirement> requirement;

	/**
	 * The cached value of the '{@link #getReference() <em>Reference</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReference()
	 * @generated
	 * @ordered
	 */
	protected EList<Reference> reference;

	/**
	 * The cached value of the '{@link #getExstate() <em>Exstate</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExstate()
	 * @generated
	 * @ordered
	 */
	protected EList<StateMachine> exstate;

	/**
	 * The cached value of the '{@link #getExbdd() <em>Exbdd</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExbdd()
	 * @generated
	 * @ordered
	 */
	protected EList<BDD> exbdd;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProblemFrameworkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ProblemframeworkPackage.Literals.PROBLEM_FRAMEWORK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ProblemframeworkPackage.PROBLEM_FRAMEWORK__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Domain> getDomain() {
		if (domain == null) {
			domain = new EObjectContainmentEList<Domain>(Domain.class, this, ProblemframeworkPackage.PROBLEM_FRAMEWORK__DOMAIN);
		}
		return domain;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Machine> getMachine() {
		if (machine == null) {
			machine = new EObjectContainmentEList<Machine>(Machine.class, this, ProblemframeworkPackage.PROBLEM_FRAMEWORK__MACHINE);
		}
		return machine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Phenomenon> getPhenomenon() {
		if (phenomenon == null) {
			phenomenon = new EObjectContainmentEList<Phenomenon>(Phenomenon.class, this, ProblemframeworkPackage.PROBLEM_FRAMEWORK__PHENOMENON);
		}
		return phenomenon;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Requirement> getRequirement() {
		if (requirement == null) {
			requirement = new EObjectContainmentEList<Requirement>(Requirement.class, this, ProblemframeworkPackage.PROBLEM_FRAMEWORK__REQUIREMENT);
		}
		return requirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Reference> getReference() {
		if (reference == null) {
			reference = new EObjectContainmentEList<Reference>(Reference.class, this, ProblemframeworkPackage.PROBLEM_FRAMEWORK__REFERENCE);
		}
		return reference;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<StateMachine> getExstate() {
		if (exstate == null) {
			exstate = new EObjectContainmentEList<StateMachine>(StateMachine.class, this, ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXSTATE);
		}
		return exstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<BDD> getExbdd() {
		if (exbdd == null) {
			exbdd = new EObjectContainmentEList<BDD>(BDD.class, this, ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXBDD);
		}
		return exbdd;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__DOMAIN:
				return ((InternalEList<?>)getDomain()).basicRemove(otherEnd, msgs);
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__MACHINE:
				return ((InternalEList<?>)getMachine()).basicRemove(otherEnd, msgs);
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__PHENOMENON:
				return ((InternalEList<?>)getPhenomenon()).basicRemove(otherEnd, msgs);
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__REQUIREMENT:
				return ((InternalEList<?>)getRequirement()).basicRemove(otherEnd, msgs);
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__REFERENCE:
				return ((InternalEList<?>)getReference()).basicRemove(otherEnd, msgs);
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXSTATE:
				return ((InternalEList<?>)getExstate()).basicRemove(otherEnd, msgs);
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXBDD:
				return ((InternalEList<?>)getExbdd()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__NAME:
				return getName();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__DOMAIN:
				return getDomain();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__MACHINE:
				return getMachine();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__PHENOMENON:
				return getPhenomenon();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__REQUIREMENT:
				return getRequirement();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__REFERENCE:
				return getReference();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXSTATE:
				return getExstate();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXBDD:
				return getExbdd();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__NAME:
				setName((String)newValue);
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__DOMAIN:
				getDomain().clear();
				getDomain().addAll((Collection<? extends Domain>)newValue);
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__MACHINE:
				getMachine().clear();
				getMachine().addAll((Collection<? extends Machine>)newValue);
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__PHENOMENON:
				getPhenomenon().clear();
				getPhenomenon().addAll((Collection<? extends Phenomenon>)newValue);
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__REQUIREMENT:
				getRequirement().clear();
				getRequirement().addAll((Collection<? extends Requirement>)newValue);
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__REFERENCE:
				getReference().clear();
				getReference().addAll((Collection<? extends Reference>)newValue);
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXSTATE:
				getExstate().clear();
				getExstate().addAll((Collection<? extends StateMachine>)newValue);
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXBDD:
				getExbdd().clear();
				getExbdd().addAll((Collection<? extends BDD>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__NAME:
				setName(NAME_EDEFAULT);
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__DOMAIN:
				getDomain().clear();
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__MACHINE:
				getMachine().clear();
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__PHENOMENON:
				getPhenomenon().clear();
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__REQUIREMENT:
				getRequirement().clear();
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__REFERENCE:
				getReference().clear();
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXSTATE:
				getExstate().clear();
				return;
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXBDD:
				getExbdd().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__DOMAIN:
				return domain != null && !domain.isEmpty();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__MACHINE:
				return machine != null && !machine.isEmpty();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__PHENOMENON:
				return phenomenon != null && !phenomenon.isEmpty();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__REQUIREMENT:
				return requirement != null && !requirement.isEmpty();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__REFERENCE:
				return reference != null && !reference.isEmpty();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXSTATE:
				return exstate != null && !exstate.isEmpty();
			case ProblemframeworkPackage.PROBLEM_FRAMEWORK__EXBDD:
				return exbdd != null && !exbdd.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //ProblemFrameworkImpl
