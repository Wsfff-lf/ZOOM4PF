/**
 */
package problemframework;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Item Flow</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link problemframework.ItemFlow#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.ItemFlow#getFlowkind <em>Flowkind</em>}</li>
 *   <li>{@link problemframework.ItemFlow#getSource <em>Source</em>}</li>
 *   <li>{@link problemframework.ItemFlow#getTarget <em>Target</em>}</li>
 * </ul>
 *
 * @see problemframework.ProblemframeworkPackage#getItemFlow()
 * @model
 * @generated
 */
public interface ItemFlow extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see problemframework.ProblemframeworkPackage#getItemFlow_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link problemframework.ItemFlow#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Flowkind</b></em>' attribute.
	 * The literals are from the enumeration {@link problemframework.FlowKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Flowkind</em>' attribute.
	 * @see problemframework.FlowKind
	 * @see #setFlowkind(FlowKind)
	 * @see problemframework.ProblemframeworkPackage#getItemFlow_Flowkind()
	 * @model
	 * @generated
	 */
	FlowKind getFlowkind();

	/**
	 * Sets the value of the '{@link problemframework.ItemFlow#getFlowkind <em>Flowkind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Flowkind</em>' attribute.
	 * @see problemframework.FlowKind
	 * @see #getFlowkind()
	 * @generated
	 */
	void setFlowkind(FlowKind value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Port)
	 * @see problemframework.ProblemframeworkPackage#getItemFlow_Source()
	 * @model
	 * @generated
	 */
	Port getSource();

	/**
	 * Sets the value of the '{@link problemframework.ItemFlow#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Port value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(Port)
	 * @see problemframework.ProblemframeworkPackage#getItemFlow_Target()
	 * @model
	 * @generated
	 */
	Port getTarget();

	/**
	 * Sets the value of the '{@link problemframework.ItemFlow#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(Port value);

} // ItemFlow
