/**
 */
package problemframework;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IBD</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link problemframework.IBD#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.IBD#getPart <em>Part</em>}</li>
 *   <li>{@link problemframework.IBD#getPort <em>Port</em>}</li>
 *   <li>{@link problemframework.IBD#getConnect <em>Connect</em>}</li>
 *   <li>{@link problemframework.IBD#getItemflow <em>Itemflow</em>}</li>
 * </ul>
 *
 * @see problemframework.ProblemframeworkPackage#getIBD()
 * @model
 * @generated
 */
public interface IBD extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see problemframework.ProblemframeworkPackage#getIBD_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link problemframework.IBD#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Part</b></em>' containment reference list.
	 * The list contents are of type {@link problemframework.Part}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Part</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getIBD_Part()
	 * @model containment="true"
	 * @generated
	 */
	EList<Part> getPart();

	/**
	 * Returns the value of the '<em><b>Port</b></em>' containment reference list.
	 * The list contents are of type {@link problemframework.Port}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getIBD_Port()
	 * @model containment="true"
	 * @generated
	 */
	EList<Port> getPort();

	/**
	 * Returns the value of the '<em><b>Connect</b></em>' containment reference list.
	 * The list contents are of type {@link problemframework.Connect}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connect</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getIBD_Connect()
	 * @model containment="true"
	 * @generated
	 */
	EList<Connect> getConnect();

	/**
	 * Returns the value of the '<em><b>Itemflow</b></em>' containment reference list.
	 * The list contents are of type {@link problemframework.ItemFlow}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Itemflow</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getIBD_Itemflow()
	 * @model containment="true"
	 * @generated
	 */
	EList<ItemFlow> getItemflow();

} // IBD
