/**
 */
package problemframework;

import BlockdDiagram.BDD;
import org.eclipse.emf.common.util.EList;
import stateMachine.StateMachine;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Problem Framework</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link problemframework.ProblemFramework#getName <em>Name</em>}</li>
 *   <li>{@link problemframework.ProblemFramework#getDomain <em>Domain</em>}</li>
 *   <li>{@link problemframework.ProblemFramework#getMachine <em>Machine</em>}</li>
 *   <li>{@link problemframework.ProblemFramework#getPhenomenon <em>Phenomenon</em>}</li>
 *   <li>{@link problemframework.ProblemFramework#getRequirement <em>Requirement</em>}</li>
 *   <li>{@link problemframework.ProblemFramework#getReference <em>Reference</em>}</li>
 *   <li>{@link problemframework.ProblemFramework#getExstate <em>Exstate</em>}</li>
 *   <li>{@link problemframework.ProblemFramework#getExbdd <em>Exbdd</em>}</li>
 * </ul>
 *
 * @see problemframework.ProblemframeworkPackage#getProblemFramework()
 * @model
 * @generated
 */
public interface ProblemFramework extends SubPF {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see problemframework.ProblemframeworkPackage#getProblemFramework_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link problemframework.ProblemFramework#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Domain</b></em>' containment reference list.
	 * The list contents are of type {@link problemframework.Domain}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Domain</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getProblemFramework_Domain()
	 * @model containment="true"
	 * @generated
	 */
	EList<Domain> getDomain();

	/**
	 * Returns the value of the '<em><b>Machine</b></em>' containment reference list.
	 * The list contents are of type {@link problemframework.Machine}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Machine</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getProblemFramework_Machine()
	 * @model containment="true"
	 * @generated
	 */
	EList<Machine> getMachine();

	/**
	 * Returns the value of the '<em><b>Phenomenon</b></em>' containment reference list.
	 * The list contents are of type {@link problemframework.Phenomenon}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Phenomenon</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getProblemFramework_Phenomenon()
	 * @model containment="true"
	 * @generated
	 */
	EList<Phenomenon> getPhenomenon();

	/**
	 * Returns the value of the '<em><b>Requirement</b></em>' containment reference list.
	 * The list contents are of type {@link problemframework.Requirement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Requirement</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getProblemFramework_Requirement()
	 * @model containment="true"
	 * @generated
	 */
	EList<Requirement> getRequirement();

	/**
	 * Returns the value of the '<em><b>Reference</b></em>' containment reference list.
	 * The list contents are of type {@link problemframework.Reference}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reference</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getProblemFramework_Reference()
	 * @model containment="true"
	 * @generated
	 */
	EList<Reference> getReference();

	/**
	 * Returns the value of the '<em><b>Exstate</b></em>' containment reference list.
	 * The list contents are of type {@link stateMachine.StateMachine}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exstate</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getProblemFramework_Exstate()
	 * @model containment="true"
	 * @generated
	 */
	EList<StateMachine> getExstate();

	/**
	 * Returns the value of the '<em><b>Exbdd</b></em>' containment reference list.
	 * The list contents are of type {@link BlockdDiagram.BDD}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exbdd</em>' containment reference list.
	 * @see problemframework.ProblemframeworkPackage#getProblemFramework_Exbdd()
	 * @model containment="true"
	 * @generated
	 */
	EList<BDD> getExbdd();

} // ProblemFramework
